use serde::{Deserialize, Serialize};
use validator::Validate;

use crate::models::vault_item::{CustomField, ItemType};

// ── Create ────────────────────────────────────────────────────────────────────

#[derive(Debug, Deserialize, Validate)]
pub struct CreateItemRequest {
    pub item_type: ItemType,

    /// Encrypted item name
    #[validate(length(min = 1, max = 1000))]
    pub name: String,

    /// Full AES-256-GCM encrypted payload — opaque to the server
    #[validate(length(min = 1))]
    pub encrypted_data: String,

    pub notes:         Option<String>,
    pub custom_fields: Option<Vec<CustomField>>,
    pub tags:          Option<Vec<String>>,
    pub favourite:     Option<bool>,
    pub reprompt:      Option<bool>,
    pub collection_ids: Option<Vec<String>>,
}

// ── Update ────────────────────────────────────────────────────────────────────

#[derive(Debug, Deserialize, Validate)]
pub struct UpdateItemRequest {
    #[validate(length(min = 1, max = 1000))]
    pub name: String,

    #[validate(length(min = 1))]
    pub encrypted_data: String,

    pub notes:          Option<String>,
    pub custom_fields:  Option<Vec<CustomField>>,
    pub tags:           Option<Vec<String>>,
    pub favourite:      Option<bool>,
    pub reprompt:       Option<bool>,
    pub collection_ids: Option<Vec<String>>,
}

// ── Patch (partial) ───────────────────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct PatchItemRequest {
    pub favourite: Option<bool>,
    pub reprompt:  Option<bool>,
}

// ── Response ──────────────────────────────────────────────────────────────────

#[derive(Debug, Serialize)]
pub struct VaultItemResponse {
    pub id:             String,
    pub item_type:      ItemType,
    pub name:           String,
    pub encrypted_data: String,
    pub notes:          Option<String>,
    pub custom_fields:  Vec<CustomField>,
    pub tags:           Vec<String>,
    pub favourite:      bool,
    pub reprompt:       bool,
    pub collection_ids: Vec<String>,
    pub revision_date:  String,
    pub created_at:     String,
    pub updated_at:     String,
}

// ── List response ─────────────────────────────────────────────────────────────

#[derive(Debug, Serialize)]
pub struct VaultItemListResponse {
    pub data:        Vec<VaultItemResponse>,
    pub has_more:    bool,
    pub next_cursor: Option<String>,
}

// ── Collection DTOs ───────────────────────────────────────────────────────────

#[derive(Debug, Deserialize, Validate)]
pub struct CreateCollectionRequest {
    #[validate(length(min = 1, max = 500))]
    pub name: String,

    pub hide_passwords: Option<bool>,
    pub read_only:      Option<bool>,
}

#[derive(Debug, Serialize)]
pub struct CollectionResponse {
    pub id:             String,
    pub name:           String,
    pub hide_passwords: bool,
    pub read_only:      bool,
    pub created_at:     String,
}
