use serde::{Deserialize, Serialize};
use validator::Validate;

// ── Register ─────────────────────────────────────────────────────────────────

#[derive(Debug, Deserialize, Validate)]
pub struct RegisterRequest {
    #[validate(email(message = "Invalid email address"))]
    pub email: String,

    /// The client-derived Master Password Hash (MPH), base64-encoded.
    /// Never the actual master password.
    #[validate(length(min = 32, message = "master_password_hash too short"))]
    pub master_password_hash: String,

    /// Optional human-readable hint (never the password itself)
    pub master_key_hint: Option<String>,

    /// AES-256-GCM encrypted vault key, base64.
    /// Client generates a random 512-bit vault key, encrypts with their
    /// Encryption Key (EK derived from master password), sends us the blob.
    #[validate(length(min = 1, message = "protected_symmetric_key is required"))]
    pub protected_symmetric_key: String,

    /// Client's KDF parameters so we can echo them back at login
    pub kdf_iterations:  u32,
    pub kdf_memory:      u32,
    pub kdf_parallelism: u32,
    pub kdf_salt:        String,
}

#[derive(Debug, Serialize)]
pub struct RegisterResponse {
    pub user_id: String,
    pub email:   String,
}

// ── Login step 1 ─────────────────────────────────────────────────────────────

#[derive(Debug, Deserialize, Validate)]
pub struct LoginRequest {
    #[validate(email)]
    pub email: String,

    /// Client-derived MPH
    pub master_password_hash: String,

    pub device_id:  Option<String>,
    pub user_agent: Option<String>,
}

/// Returned after successful password verification.
/// If 2FA is enabled, `requires_two_factor = true` and tokens are absent.
/// The client must call POST /auth/two-factor next.
#[derive(Debug, Serialize)]
pub struct LoginResponse {
    pub requires_two_factor:   bool,
    pub two_factor_token:      Option<String>,   // short-lived token to pass to step 2
    pub access_token:          Option<String>,
    pub refresh_token:         Option<String>,
    pub access_token_expires:  Option<i64>,      // unix timestamp
    pub user:                  Option<UserProfile>,
    pub kdf:                   Option<KdfParams>, // so client can re-derive keys
}

// ── Login step 2 (2FA) ───────────────────────────────────────────────────────

#[derive(Debug, Deserialize, Validate)]
pub struct TwoFactorRequest {
    /// The short-lived token from step 1
    pub two_factor_token: String,
    /// TOTP code or recovery code
    pub code:             String,
    pub method:           TwoFactorMethod,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TwoFactorMethod {
    Totp,
    RecoveryCode,
}

#[derive(Debug, Serialize)]
pub struct TokenPair {
    pub access_token:         String,
    pub refresh_token:        String,
    pub access_token_expires: i64,
    pub user:                 UserProfile,
    pub kdf:                  KdfParams,
}

// ── Refresh ───────────────────────────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct RefreshRequest {
    pub refresh_token: String,
}

// ── Change password ───────────────────────────────────────────────────────────

#[derive(Debug, Deserialize, Validate)]
pub struct ChangePasswordRequest {
    pub current_master_password_hash: String,
    pub new_master_password_hash:     String,
    /// Re-encrypted vault key (encrypted with the new Encryption Key)
    pub new_protected_symmetric_key:  String,
}

// ── Shared sub-types ─────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize)]
pub struct UserProfile {
    pub user_id:             String,
    pub email:               String,
    pub email_verified:      bool,
    pub two_factor_enabled:  bool,
    pub protected_symmetric_key: String,   // client needs this to unwrap vault key
    pub kdf:                 KdfParams,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KdfParams {
    pub algorithm:   String,
    pub iterations:  u32,
    pub memory:      u32,
    pub parallelism: u32,
    pub salt:        String,
}
