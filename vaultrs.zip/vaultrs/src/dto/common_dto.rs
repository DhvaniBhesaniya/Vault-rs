use serde::Serialize;

#[derive(Debug, Serialize)]
pub struct MessageResponse {
    pub message: String,
}

impl MessageResponse {
    pub fn ok(msg: impl Into<String>) -> Self {
        Self { message: msg.into() }
    }
}

#[derive(Debug, Serialize)]
pub struct IdResponse {
    pub id: String,
}
