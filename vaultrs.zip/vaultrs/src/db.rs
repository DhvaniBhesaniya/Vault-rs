use anyhow::{Context, Result};
use mongodb::{
    bson::doc,
    options::{ClientOptions, IndexOptions},
    Client, Collection, Database, IndexModel,
};
use std::time::Duration;
use tracing::info;

use crate::models::{
    audit_log::AuditLog,
    collection::VaultCollection,
    idempotency::IdempotencyRecord,
    organization::{OrgMember, Organization},
    refresh_token::RefreshToken,
    user::User,
    vault_item::VaultItem,
};

#[derive(Debug, Clone)]
pub struct Db {
    pub client: Client,
    pub database: Database,
}

impl Db {
    pub async fn connect(uri: &str, db_name: &str) -> Result<Self> {
        let mut opts = ClientOptions::parse(uri)
            .await
            .context("Failed to parse MongoDB URI")?;

        opts.app_name          = Some("vaultrs".into());
        opts.connect_timeout   = Some(Duration::from_secs(10));
        opts.server_selection_timeout = Some(Duration::from_secs(10));
        opts.max_pool_size     = Some(20);
        opts.min_pool_size     = Some(2);

        let client   = Client::with_options(opts).context("Failed to create MongoDB client")?;
        let database = client.database(db_name);

        // Ping to verify connectivity
        database
            .run_command(doc! { "ping": 1 })
            .await
            .context("MongoDB ping failed — is the server running?")?;

        info!(db = db_name, "Connected to MongoDB");

        Ok(Self { client, database })
    }

    // ── Collection accessors ─────────────────────────────────────────────────

    pub fn users(&self) -> Collection<User> {
        self.database.collection("users")
    }

    pub fn vault_items(&self) -> Collection<VaultItem> {
        self.database.collection("vault_items")
    }

    pub fn collections(&self) -> Collection<VaultCollection> {
        self.database.collection("collections")
    }

    pub fn organizations(&self) -> Collection<Organization> {
        self.database.collection("organizations")
    }

    pub fn org_members(&self) -> Collection<OrgMember> {
        self.database.collection("org_members")
    }

    pub fn refresh_tokens(&self) -> Collection<RefreshToken> {
        self.database.collection("refresh_tokens")
    }

    pub fn audit_logs(&self) -> Collection<AuditLog> {
        self.database.collection("audit_logs")
    }

    pub fn idempotency_records(&self) -> Collection<IdempotencyRecord> {
        self.database.collection("idempotency_records")
    }

    // ── Index bootstrap ──────────────────────────────────────────────────────

    pub async fn create_indexes(&self) -> Result<()> {
        info!("Creating MongoDB indexes…");

        // users
        self.users()
            .create_indexes(vec![
                unique_index(doc! { "email": 1 }),
                unique_index(doc! { "public_id": 1 }),
            ])
            .await?;

        // vault_items
        self.vault_items()
            .create_indexes(vec![
                index(doc! { "user_id": 1, "deleted_at": 1 }),
                index(doc! { "user_id": 1, "type": 1 }),
                index(doc! { "collection_ids": 1 }),
                unique_index(doc! { "public_id": 1 }),
                index(doc! { "updated_at": -1 }),
            ])
            .await?;

        // refresh_tokens — TTL on expires_at
        self.refresh_tokens()
            .create_indexes(vec![
                unique_index(doc! { "token_hash": 1 }),
                index(doc! { "user_id": 1 }),
                ttl_index(doc! { "expires_at": 1 }, 0),
            ])
            .await?;

        // audit_logs — TTL 90 days
        self.audit_logs()
            .create_indexes(vec![
                index(doc! { "actor_user_id": 1, "created_at": -1 }),
                index(doc! { "organization_id": 1, "created_at": -1 }),
                ttl_index(doc! { "created_at": 1 }, 7_776_000),  // 90 days
            ])
            .await?;

        // idempotency_records — TTL 24 hours
        self.idempotency_records()
            .create_indexes(vec![
                index(doc! { "user_id": 1 }),
                ttl_index(doc! { "created_at": 1 }, 86_400),  // 24 hours
            ])
            .await?;

        // org_members
        self.org_members()
            .create_indexes(vec![
                unique_index(doc! { "organization_id": 1, "user_id": 1 }),
                index(doc! { "user_id": 1 }),
            ])
            .await?;

        info!("MongoDB indexes ready");
        Ok(())
    }
}

// ── Index builder helpers ────────────────────────────────────────────────────

fn index(keys: mongodb::bson::Document) -> IndexModel {
    IndexModel::builder().keys(keys).build()
}

fn unique_index(keys: mongodb::bson::Document) -> IndexModel {
    IndexModel::builder()
        .keys(keys)
        .options(IndexOptions::builder().unique(true).build())
        .build()
}

fn ttl_index(keys: mongodb::bson::Document, expire_after_seconds: u64) -> IndexModel {
    IndexModel::builder()
        .keys(keys)
        .options(
            IndexOptions::builder()
                .expire_after(Duration::from_secs(expire_after_seconds))
                .build(),
        )
        .build()
}
