use aes_gcm::{
    aead::{Aead, KeyInit, OsRng, Payload},
    Aes256Gcm, Key, Nonce,
};
use base64::{engine::general_purpose::STANDARD as B64, Engine};
use rand::RngCore;

use crate::error::{AppError, AppResult};

const VERSION_PREFIX: &str = "$aes256gcm$";
const NONCE_LEN: usize = 12;   // 96-bit IV for GCM
const KEY_LEN:   usize = 32;   // 256-bit key

/// Encrypt plaintext with AES-256-GCM.
///
/// # Arguments
/// * `key_bytes` — 32-byte vault key
/// * `plaintext` — arbitrary bytes to encrypt
/// * `aad`       — Additional Authenticated Data (e.g. item_id|user_id).
///                 Authenticated but NOT encrypted.  Prevents ciphertext
///                 from being transplanted to a different record.
///
/// # Output format
///   `"$aes256gcm$" + base64( nonce[12] || ciphertext || tag[16] )`
pub fn encrypt(
    key_bytes: &[u8; KEY_LEN],
    plaintext: &[u8],
    aad: &[u8],
) -> AppResult<String> {
    let key    = Key::<Aes256Gcm>::from_slice(key_bytes);
    let cipher = Aes256Gcm::new(key);

    let mut nonce_bytes = [0u8; NONCE_LEN];
    OsRng.fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);

    let ciphertext = cipher
        .encrypt(nonce, Payload { msg: plaintext, aad })
        .map_err(|_| AppError::Crypto)?;

    // Prepend nonce before ciphertext+tag blob
    let mut blob = Vec::with_capacity(NONCE_LEN + ciphertext.len());
    blob.extend_from_slice(&nonce_bytes);
    blob.extend_from_slice(&ciphertext);

    Ok(format!("{}{}", VERSION_PREFIX, B64.encode(&blob)))
}

/// Decrypt a ciphertext produced by [`encrypt`].
///
/// Verifies the GCM authentication tag AND the AAD binding before returning
/// plaintext.  Returns `AppError::Crypto` on any failure (bad key, tampered
/// data, wrong AAD) — never leaks which check failed.
pub fn decrypt(
    key_bytes: &[u8; KEY_LEN],
    ciphertext_str: &str,
    aad: &[u8],
) -> AppResult<Vec<u8>> {
    let b64_part = ciphertext_str
        .strip_prefix(VERSION_PREFIX)
        .ok_or(AppError::Crypto)?;

    let blob = B64.decode(b64_part).map_err(|_| AppError::Crypto)?;
    if blob.len() < NONCE_LEN + 16 {
        return Err(AppError::Crypto);
    }

    let (nonce_bytes, cipher_and_tag) = blob.split_at(NONCE_LEN);
    let nonce  = Nonce::from_slice(nonce_bytes);
    let key    = Key::<Aes256Gcm>::from_slice(key_bytes);
    let cipher = Aes256Gcm::new(key);

    cipher
        .decrypt(nonce, Payload { msg: cipher_and_tag, aad })
        .map_err(|_| AppError::Crypto)
}

/// Build the AAD string used for vault item binding.
///
/// Ensures a ciphertext blob cannot be moved from one user/item to another
/// without breaking the GCM tag.
pub fn item_aad(item_public_id: &str, user_public_id: &str) -> Vec<u8> {
    format!("{}|{}", item_public_id, user_public_id).into_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn test_key() -> [u8; 32] {
        [0x42u8; 32]
    }

    #[test]
    fn round_trip() {
        let key       = test_key();
        let plaintext = b"super secret password: hunter2";
        let aad       = b"item-uuid|user-uuid";

        let enc = encrypt(&key, plaintext, aad).unwrap();
        assert!(enc.starts_with("$aes256gcm$"));

        let dec = decrypt(&key, &enc, aad).unwrap();
        assert_eq!(dec, plaintext);
    }

    #[test]
    fn wrong_aad_fails() {
        let key  = test_key();
        let enc  = encrypt(&key, b"data", b"correct-aad").unwrap();
        let result = decrypt(&key, &enc, b"wrong-aad");
        assert!(result.is_err());
    }

    #[test]
    fn tampered_ciphertext_fails() {
        let key = test_key();
        let mut enc = encrypt(&key, b"data", b"aad").unwrap();
        // Flip a byte in the base64 payload
        let idx = enc.len() - 5;
        unsafe {
            let bytes = enc.as_bytes_mut();
            bytes[idx] ^= 0xFF;
        }
        assert!(decrypt(&key, &enc, b"aad").is_err());
    }
}
