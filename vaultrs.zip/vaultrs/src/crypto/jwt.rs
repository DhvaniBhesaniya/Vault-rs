use chrono::{Duration, Utc};
use jsonwebtoken::{decode, encode, Algorithm, DecodingKey, EncodingKey, Header, Validation};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::error::{AppError, AppResult};
use crate::models::common::SystemRole;

/// Claims embedded in every access token
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Claims {
    pub sub:            String,   // user public_id (UUID)
    pub jti:            String,   // unique token ID for revocation
    pub iat:            i64,
    pub exp:            i64,
    pub email:          String,
    pub roles:          Vec<SystemRole>,
    pub security_stamp: String,   // rotated on password change
    pub org_ids:        Vec<String>,
}

/// Thin wrapper around the RS256 key pair
#[derive(Clone)]
pub struct JwtKeys {
    encoding: EncodingKey,
    decoding: DecodingKey,
    pub access_expiry_seconds: u64,
}

impl JwtKeys {
    pub fn new(
        private_pem: &str,
        public_pem: &str,
        access_expiry_seconds: u64,
    ) -> AppResult<Self> {
        let encoding = EncodingKey::from_rsa_pem(private_pem.as_bytes())
            .map_err(|_| AppError::Crypto)?;
        let decoding = DecodingKey::from_rsa_pem(public_pem.as_bytes())
            .map_err(|_| AppError::Crypto)?;
        Ok(Self { encoding, decoding, access_expiry_seconds })
    }

    /// Issue a signed RS256 access token
    pub fn sign(
        &self,
        user_public_id: &Uuid,
        email: &str,
        roles: Vec<SystemRole>,
        security_stamp: &Uuid,
        org_ids: Vec<String>,
    ) -> AppResult<String> {
        let now = Utc::now();
        let claims = Claims {
            sub:            user_public_id.to_string(),
            jti:            Uuid::new_v4().to_string(),
            iat:            now.timestamp(),
            exp:            (now + Duration::seconds(self.access_expiry_seconds as i64)).timestamp(),
            email:          email.to_string(),
            roles,
            security_stamp: security_stamp.to_string(),
            org_ids,
        };

        encode(&Header::new(Algorithm::RS256), &claims, &self.encoding)
            .map_err(|_| AppError::Crypto)
    }

    /// Verify and decode an access token.
    /// Does NOT check security_stamp — the auth middleware does that against the DB.
    pub fn verify(&self, token: &str) -> AppResult<Claims> {
        let mut validation = Validation::new(Algorithm::RS256);
        validation.validate_exp = true;

        decode::<Claims>(token, &self.decoding, &validation)
            .map(|td| td.claims)
            .map_err(|e| {
                tracing::debug!(error = %e, "JWT verification failed");
                AppError::Unauthorized
            })
    }
}
