use base64::{engine::general_purpose::STANDARD as B64, Engine};
use rand::RngCore;
use sha2::{Digest, Sha256};

/// Generate a cryptographically secure opaque token (256-bit / 32 bytes),
/// returned as a URL-safe base64 string.
/// Used for refresh tokens, email verification tokens, etc.
pub fn generate_opaque_token() -> String {
    let mut bytes = [0u8; 32];
    rand::thread_rng().fill_bytes(&mut bytes);
    B64.encode(bytes)
}

/// SHA-256 hash of an opaque token for safe storage.
/// We store the hash, never the raw token.
pub fn hash_token(token: &str) -> String {
    let digest = Sha256::digest(token.as_bytes());
    hex::encode(digest)
}

/// Generate a random 32-byte key returned as raw bytes.
/// Used internally for vault key generation.
pub fn generate_key_bytes() -> [u8; 32] {
    let mut key = [0u8; 32];
    rand::thread_rng().fill_bytes(&mut key);
    key
}

// hex is a lightweight dep; add it to Cargo.toml
// hex = "0.4"
