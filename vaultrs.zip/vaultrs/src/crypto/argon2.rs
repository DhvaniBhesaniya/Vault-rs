use argon2::{
    password_hash::{rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Argon2, Params, Version,
};
use secrecy::{ExposeSecret, Secret};

use crate::error::{AppError, AppResult};

/// Server-side Argon2id parameters.
/// These are applied to the client-derived Master Password Hash (MPH).
/// The MPH has already been stretched client-side with Argon2id at equal
/// or higher memory cost — this is a second layer of hashing.
pub struct Argon2Config {
    pub memory_kib:  u32,
    pub iterations:  u32,
    pub parallelism: u32,
}

impl Default for Argon2Config {
    fn default() -> Self {
        Self {
            memory_kib:  65_536,   // 64 MB
            iterations:  3,
            parallelism: 4,
        }
    }
}

/// Hash a password (or MPH) using Argon2id.
///
/// Returns the full PHC string including algorithm, params, salt, and hash.
/// Safe to store directly in the database.
pub fn hash_password(
    password: &Secret<String>,
    config: &Argon2Config,
) -> AppResult<String> {
    let params = Params::new(
        config.memory_kib,
        config.iterations,
        config.parallelism,
        None,
    )
    .map_err(|_| AppError::Crypto)?;

    let argon2 = Argon2::new(argon2::Algorithm::Argon2id, Version::V0x13, params);
    let salt   = SaltString::generate(&mut OsRng);

    argon2
        .hash_password(password.expose_secret().as_bytes(), &salt)
        .map(|h| h.to_string())
        .map_err(|_| AppError::Crypto)
}

/// Verify a password against an Argon2id PHC hash string.
///
/// Uses constant-time comparison internally.
/// Returns Ok(()) on match, Err(AppError::InvalidCredentials) on mismatch.
pub fn verify_password(
    password: &Secret<String>,
    hash: &str,
) -> AppResult<()> {
    let parsed = PasswordHash::new(hash).map_err(|_| AppError::Crypto)?;

    Argon2::default()
        .verify_password(password.expose_secret().as_bytes(), &parsed)
        .map_err(|_| AppError::InvalidCredentials)
}

/// Generate a cryptographically random salt, base64-encoded.
/// Used when creating a new user account (client uses this salt for their
/// client-side Argon2id derivation).
pub fn generate_kdf_salt() -> String {
    use base64::{engine::general_purpose::STANDARD, Engine};
    use rand::RngCore;

    let mut salt = [0u8; 16];  // 128 bits
    rand::thread_rng().fill_bytes(&mut salt);
    STANDARD.encode(salt)
}
