use chrono::{DateTime, Utc};
use mongodb::bson::oid::ObjectId;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Organization {
    #[serde(rename = "_id", skip_serializing_if = "Option::is_none")]
    pub id: Option<ObjectId>,

    pub public_id:     Uuid,
    pub name:          String,
    pub billing_email: String,
    pub two_factor_required: bool,
    pub created_at:    DateTime<Utc>,
    pub updated_at:    DateTime<Utc>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OrgRole {
    Owner,
    Admin,
    Manager,
    Member,
    Viewer,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MemberStatus {
    Invited,
    Accepted,
    Confirmed,
    Revoked,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CollectionAccess {
    pub collection_id:  ObjectId,
    pub read_only:      bool,
    pub hide_passwords: bool,
    pub manage:         bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrgMember {
    #[serde(rename = "_id", skip_serializing_if = "Option::is_none")]
    pub id: Option<ObjectId>,

    pub organization_id: ObjectId,
    pub user_id:         ObjectId,
    pub role:            OrgRole,
    pub status:          MemberStatus,
    pub collections:     Vec<CollectionAccess>,

    /// Org vault key encrypted with member's RSA public key.
    /// Only set after member has confirmed (Confirmed status).
    pub protected_symmetric_key: Option<String>,

    pub invited_at:    DateTime<Utc>,
    pub confirmed_at:  Option<DateTime<Utc>>,
}

impl OrgMember {
    pub fn can_write(&self) -> bool {
        matches!(self.role, OrgRole::Owner | OrgRole::Admin | OrgRole::Manager | OrgRole::Member)
            && self.status == MemberStatus::Confirmed
    }

    pub fn can_manage_members(&self) -> bool {
        matches!(self.role, OrgRole::Owner | OrgRole::Admin)
            && self.status == MemberStatus::Confirmed
    }

    pub fn is_owner(&self) -> bool {
        self.role == OrgRole::Owner
    }
}
