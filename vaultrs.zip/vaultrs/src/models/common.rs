use serde::{Deserialize, Serialize};

/// Cursor-based pagination parameters
#[derive(Debug, Deserialize)]
pub struct Pagination {
    pub after:  Option<String>,   // last seen public_id
    #[serde(default = "default_limit")]
    pub limit:  u32,
}

fn default_limit() -> u32 { 50 }

/// Standard paginated response envelope
#[derive(Debug, Serialize)]
pub struct Page<T: Serialize> {
    pub data:        Vec<T>,
    pub has_more:    bool,
    pub next_cursor: Option<String>,
}

impl<T: Serialize> Page<T> {
    pub fn new(mut data: Vec<T>, limit: u32, next_cursor_fn: impl Fn(&T) -> String) -> Self {
        let has_more = data.len() > limit as usize;
        if has_more { data.truncate(limit as usize); }
        let next_cursor = if has_more {
            data.last().map(&next_cursor_fn)
        } else {
            None
        };
        Self { data, has_more, next_cursor }
    }
}

/// RBAC roles at the system level
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SystemRole {
    SuperAdmin,
    User,
    ApiAccess,
}

impl Default for SystemRole {
    fn default() -> Self { Self::User }
}
