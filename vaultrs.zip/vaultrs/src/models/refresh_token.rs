// ── refresh_token.rs ─────────────────────────────────────────────────────────
use chrono::{DateTime, Utc};
use mongodb::bson::oid::ObjectId;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RefreshToken {
    #[serde(rename = "_id", skip_serializing_if = "Option::is_none")]
    pub id: Option<ObjectId>,

    pub user_id:     ObjectId,
    /// SHA-256 hash of the opaque 256-bit token string
    pub token_hash:  String,
    /// All tokens in the same rotation chain share a family_id.
    /// Double-use of any token → revoke entire family (theft detected).
    pub family_id:   Uuid,

    pub device_id:   String,
    pub ip_address:  String,
    pub user_agent:  String,

    pub expires_at:  DateTime<Utc>,   // MongoDB TTL index on this field
    pub revoked_at:  Option<DateTime<Utc>>,
    pub created_at:  DateTime<Utc>,
}

impl RefreshToken {
    pub fn is_valid(&self) -> bool {
        self.revoked_at.is_none() && self.expires_at > Utc::now()
    }
}
