use chrono::{DateTime, Utc};
use mongodb::bson::oid::ObjectId;
use serde::{Deserialize, Serialize};

/// Persisted after first execution of any idempotent endpoint.
/// TTL index on `created_at` removes records after 24 hours.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdempotencyRecord {
    /// The idempotency key itself is the document _id
    #[serde(rename = "_id")]
    pub key: String,

    pub user_id:       ObjectId,
    pub method:        String,
    pub path:          String,
    pub status_code:   u16,
    pub response_body: String,

    pub created_at: DateTime<Utc>,  // TTL index: 24h
}
