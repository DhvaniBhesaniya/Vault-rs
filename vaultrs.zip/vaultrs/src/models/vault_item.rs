use chrono::{DateTime, Utc};
use mongodb::bson::oid::ObjectId;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// All supported secret categories
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ItemType {
    Login,
    SecureNote,
    CreditCard,
    Identity,
    SshKey,
    ApiKey,
    SoftwareLicense,
    DatabaseCredential,
    WifiPassword,
    BankAccount,
}

/// A custom field added by the user (name + value, value is encrypted)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CustomField {
    pub name:       String,
    pub value:      String,   // encrypted
    pub field_type: FieldType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FieldType {
    Text,
    Hidden,
    Boolean,
    Linked,
}

/// Main vault item document.
///
/// IMPORTANT: `encrypted_data` holds the AES-256-GCM ciphertext of the full
/// item payload (JSON-serialised).  The server stores it opaquely and never
/// attempts to decrypt it.  Only `name`, `type`, `favourite`, `tags`, and
/// timestamps are stored in plaintext for indexing/sorting.
///
/// Even `name` and `tags` are encrypted by the client before sending; the
/// server keeps them as opaque strings.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VaultItem {
    #[serde(rename = "_id", skip_serializing_if = "Option::is_none")]
    pub id: Option<ObjectId>,

    pub public_id:       Uuid,
    pub user_id:         ObjectId,
    pub organization_id: Option<ObjectId>,
    pub collection_ids:  Vec<ObjectId>,

    pub item_type: ItemType,

    /// Encrypted name (opaque to server)
    pub name: String,

    /// Full AES-256-GCM encrypted payload of the item-specific data.
    /// Format: "$aes256gcm$" + base64(IV[12] + ciphertext + tag[16])
    pub encrypted_data: String,

    /// Encrypted notes
    pub notes: Option<String>,

    /// Encrypted custom fields
    pub custom_fields: Vec<CustomField>,

    /// Encrypted tags
    pub tags: Vec<String>,

    pub favourite: bool,

    /// When true, the client must re-prompt for master password before showing
    pub reprompt: bool,

    pub revision_date:      DateTime<Utc>,
    pub password_changed_at: Option<DateTime<Utc>>,

    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub deleted_at: Option<DateTime<Utc>>,
}

impl VaultItem {
    pub fn is_deleted(&self) -> bool {
        self.deleted_at.is_some()
    }
}
