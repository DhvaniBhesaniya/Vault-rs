use chrono::{DateTime, Utc};
use mongodb::bson::oid::ObjectId;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::models::common::SystemRole;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct User {
    #[serde(rename = "_id", skip_serializing_if = "Option::is_none")]
    pub id: Option<ObjectId>,

    pub public_id:      Uuid,
    pub email:          String,
    pub email_verified: bool,

    // ── Zero-knowledge auth ────────────────────────────────────────────────
    /// Argon2id hash of the client-derived Master Password Hash (MPH).
    /// The MPH itself is: PBKDF2(MasterKey, master_password).
    /// We never receive or store the actual master password.
    pub master_password_hash: String,

    pub master_key_hint: Option<String>,

    /// AES-256-GCM encrypted vault key (encrypted with user's Encryption Key).
    /// Returned to the client so they can unwrap the vault key locally.
    pub protected_symmetric_key: String,

    /// RSA-4096 private key, AES-256-GCM encrypted with vault key.
    /// Used for org vault sharing.
    pub protected_private_key: Option<String>,

    /// RSA-4096 public key, stored unencrypted (public by definition).
    pub public_key: Option<String>,

    // ── KDF params (echoed to client on login so they use the same params) ─
    pub kdf_algorithm:   String,    // "argon2id"
    pub kdf_iterations:  u32,
    pub kdf_memory:      u32,       // KB
    pub kdf_parallelism: u32,
    pub kdf_salt:        String,    // base64, 128-bit random

    // ── 2FA ──────────────────────────────────────────────────────────────────
    pub two_factor_enabled: bool,
    /// TOTP secret encrypted with vault key
    pub totp_secret_encrypted: Option<String>,
    /// Argon2id-hashed recovery codes (single-use)
    pub recovery_code_hashes:  Vec<String>,

    // ── Session security ──────────────────────────────────────────────────────
    /// Rotated whenever password changes — invalidates all live access tokens
    pub security_stamp: Uuid,

    // ── Account state ────────────────────────────────────────────────────────
    pub roles:               Vec<SystemRole>,
    pub failed_login_attempts: u32,
    pub locked_until:        Option<DateTime<Utc>>,

    pub created_at:    DateTime<Utc>,
    pub updated_at:    DateTime<Utc>,
    pub last_login_at: Option<DateTime<Utc>>,
    pub deleted_at:    Option<DateTime<Utc>>,
}

impl User {
    pub fn is_locked(&self) -> bool {
        self.locked_until
            .map(|until| until > Utc::now())
            .unwrap_or(false)
    }

    pub fn has_role(&self, role: &SystemRole) -> bool {
        self.roles.contains(role)
    }

    pub fn is_super_admin(&self) -> bool {
        self.has_role(&SystemRole::SuperAdmin)
    }
}
