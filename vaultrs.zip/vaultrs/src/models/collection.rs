use chrono::{DateTime, Utc};
use mongodb::bson::oid::ObjectId;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

// ── VaultCollection ───────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VaultCollection {
    #[serde(rename = "_id", skip_serializing_if = "Option::is_none")]
    pub id: Option<ObjectId>,

    pub public_id:       Uuid,
    pub user_id:         ObjectId,
    pub organization_id: Option<ObjectId>,

    /// Encrypted name (opaque to server)
    pub name:         String,
    pub hide_passwords: bool,
    pub read_only:      bool,

    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}
