use chrono::{DateTime, Utc};
use mongodb::bson::{oid::ObjectId, Document};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AuditEvent {
    // Auth
    UserRegistered,
    UserLogin,
    UserLoginFailed,
    UserLogout,
    UserLogoutAll,
    UserPasswordChanged,
    UserTwoFactorEnabled,
    UserTwoFactorDisabled,
    UserAccountLocked,
    UserAccountUnlocked,
    // Vault
    VaultItemCreated,
    VaultItemViewed,
    VaultItemUpdated,
    VaultItemDeleted,
    VaultItemRestored,
    VaultItemPermanentlyDeleted,
    VaultExported,
    VaultImported,
    // Collections
    CollectionCreated,
    CollectionUpdated,
    CollectionDeleted,
    // Org
    OrgCreated,
    OrgMemberInvited,
    OrgMemberConfirmed,
    OrgMemberRoleChanged,
    OrgMemberRevoked,
    // Admin
    AdminUserLocked,
    AdminUserUnlocked,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditLog {
    #[serde(rename = "_id", skip_serializing_if = "Option::is_none")]
    pub id: Option<ObjectId>,

    pub actor_user_id:   Option<ObjectId>,
    pub organization_id: Option<ObjectId>,
    pub event_type:      AuditEvent,
    pub target_type:     String,
    pub target_id:       String,

    pub ip_address:      String,
    pub user_agent:      String,
    pub idempotency_key: Option<String>,
    pub metadata:        Document,

    pub created_at:      DateTime<Utc>,  // TTL index: 90 days
}
