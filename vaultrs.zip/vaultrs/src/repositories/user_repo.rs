use chrono::Utc;
use mongodb::{
    bson::{doc, oid::ObjectId},
    options::FindOneAndUpdateOptions,
    Collection,
};
use uuid::Uuid;

use crate::{
    error::{AppError, AppResult},
    models::user::User,
};

pub struct UserRepo {
    col: Collection<User>,
}

impl UserRepo {
    pub fn new(col: Collection<User>) -> Self {
        Self { col }
    }

    pub async fn find_by_id(&self, id: &ObjectId) -> AppResult<Option<User>> {
        self.col
            .find_one(doc! { "_id": id, "deleted_at": null })
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn find_by_email(&self, email: &str) -> AppResult<Option<User>> {
        self.col
            .find_one(doc! { "email": email, "deleted_at": null })
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn find_by_public_id(&self, public_id: &Uuid) -> AppResult<Option<User>> {
        self.col
            .find_one(doc! { "public_id": public_id.to_string(), "deleted_at": null })
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn email_exists(&self, email: &str) -> AppResult<bool> {
        self.col
            .count_documents(doc! { "email": email })
            .await
            .map(|n| n > 0)
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn insert(&self, user: &User) -> AppResult<ObjectId> {
        let result = self.col
            .insert_one(user)
            .await
            .map_err(|e| AppError::Database(e.to_string()))?;

        result
            .inserted_id
            .as_object_id()
            .ok_or_else(|| AppError::Database("Insert returned no ObjectId".into()))
    }

    /// Increment failed login attempts. Returns new count.
    pub async fn increment_failed_logins(&self, id: &ObjectId) -> AppResult<u32> {
        let opts = FindOneAndUpdateOptions::builder()
            .return_document(mongodb::options::ReturnDocument::After)
            .build();

        let updated: Option<User> = self.col
            .find_one_and_update(
                doc! { "_id": id },
                doc! {
                    "$inc": { "failed_login_attempts": 1 },
                    "$set": { "updated_at": bson::DateTime::from_chrono(Utc::now()) }
                },
            )
            .with_options(opts)
            .await
            .map_err(|e| AppError::Database(e.to_string()))?;

        Ok(updated.map(|u| u.failed_login_attempts).unwrap_or(0))
    }

    /// Clear failed login attempts and update last_login_at
    pub async fn record_successful_login(&self, id: &ObjectId) -> AppResult<()> {
        let now = bson::DateTime::from_chrono(Utc::now());
        self.col
            .update_one(
                doc! { "_id": id },
                doc! {
                    "$set": {
                        "failed_login_attempts": 0,
                        "locked_until": null,
                        "last_login_at": &now,
                        "updated_at": &now,
                    }
                },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Lock the account until the given DateTime
    pub async fn lock_account(
        &self,
        id: &ObjectId,
        until: chrono::DateTime<Utc>,
    ) -> AppResult<()> {
        let now  = bson::DateTime::from_chrono(Utc::now());
        let lock = bson::DateTime::from_chrono(until);
        self.col
            .update_one(
                doc! { "_id": id },
                doc! { "$set": { "locked_until": lock, "updated_at": now } },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Rotate security_stamp and update password hash.
    /// Call this whenever the master password changes.
    pub async fn update_password(
        &self,
        id: &ObjectId,
        new_hash: &str,
        new_protected_key: &str,
    ) -> AppResult<()> {
        let now = bson::DateTime::from_chrono(Utc::now());
        let new_stamp = Uuid::new_v4().to_string();

        self.col
            .update_one(
                doc! { "_id": id },
                doc! {
                    "$set": {
                        "master_password_hash":   new_hash,
                        "protected_symmetric_key": new_protected_key,
                        "security_stamp":         &new_stamp,
                        "updated_at":             &now,
                    }
                },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Soft-delete a user account
    pub async fn soft_delete(&self, id: &ObjectId) -> AppResult<()> {
        let now = bson::DateTime::from_chrono(Utc::now());
        self.col
            .update_one(
                doc! { "_id": id },
                doc! { "$set": { "deleted_at": &now, "updated_at": &now } },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }
}
