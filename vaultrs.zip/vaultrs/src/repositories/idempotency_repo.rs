use mongodb::{bson::doc, Collection};

use crate::{
    error::{AppError, AppResult},
    models::idempotency::IdempotencyRecord,
};

pub struct IdempotencyRepo {
    col: Collection<IdempotencyRecord>,
}

impl IdempotencyRepo {
    pub fn new(col: Collection<IdempotencyRecord>) -> Self { Self { col } }

    pub async fn find(&self, key: &str) -> AppResult<Option<IdempotencyRecord>> {
        self.col
            .find_one(doc! { "_id": key })
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn insert(&self, record: &IdempotencyRecord) -> AppResult<()> {
        // insert_one with duplicate key → treat as "already stored" (idempotent)
        match self.col.insert_one(record).await {
            Ok(_) => Ok(()),
            Err(e) if is_duplicate_key(&e) => Ok(()),
            Err(e) => Err(AppError::Database(e.to_string())),
        }
    }
}

fn is_duplicate_key(e: &mongodb::error::Error) -> bool {
    e.to_string().contains("E11000")
}
