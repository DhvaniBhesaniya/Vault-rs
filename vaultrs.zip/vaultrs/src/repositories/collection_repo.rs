use chrono::Utc;
use futures::TryStreamExt;
use mongodb::{bson::{doc, oid::ObjectId}, Collection};

use crate::{
    error::{AppError, AppResult},
    models::collection::VaultCollection,
};

pub struct CollectionRepo {
    col: Collection<VaultCollection>,
}

impl CollectionRepo {
    pub fn new(col: Collection<VaultCollection>) -> Self { Self { col } }

    pub async fn find_by_id(
        &self,
        id: &ObjectId,
        user_id: &ObjectId,
    ) -> AppResult<Option<VaultCollection>> {
        self.col
            .find_one(doc! { "_id": id, "user_id": user_id })
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn list_for_user(&self, user_id: &ObjectId) -> AppResult<Vec<VaultCollection>> {
        self.col
            .find(doc! { "user_id": user_id })
            .await
            .map_err(|e| AppError::Database(e.to_string()))?
            .try_collect()
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn insert(&self, col: &VaultCollection) -> AppResult<ObjectId> {
        let result = self.col
            .insert_one(col)
            .await
            .map_err(|e| AppError::Database(e.to_string()))?;

        result
            .inserted_id
            .as_object_id()
            .ok_or_else(|| AppError::Database("Insert returned no ObjectId".into()))
    }

    pub async fn update_name(
        &self,
        id: &ObjectId,
        user_id: &ObjectId,
        name: &str,
    ) -> AppResult<()> {
        let now = bson::DateTime::from_chrono(Utc::now());
        self.col
            .update_one(
                doc! { "_id": id, "user_id": user_id },
                doc! { "$set": { "name": name, "updated_at": &now } },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn delete(&self, id: &ObjectId, user_id: &ObjectId) -> AppResult<()> {
        self.col
            .delete_one(doc! { "_id": id, "user_id": user_id })
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }
}
