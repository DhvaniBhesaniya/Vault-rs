use chrono::Utc;
use futures::TryStreamExt;
use mongodb::{
    bson::{doc, oid::ObjectId},
    options::{FindOptions, FindOneAndUpdateOptions, ReturnDocument},
    Collection,
};
use uuid::Uuid;

use crate::{
    error::{AppError, AppResult},
    models::vault_item::VaultItem,
};

pub struct VaultItemRepo {
    col: Collection<VaultItem>,
}

impl VaultItemRepo {
    pub fn new(col: Collection<VaultItem>) -> Self { Self { col } }

    pub async fn find_by_id(
        &self,
        id: &ObjectId,
        user_id: &ObjectId,
    ) -> AppResult<Option<VaultItem>> {
        // The user_id predicate here is defence-in-depth:
        // even if RBAC middleware is bypassed, we never return another user's item.
        self.col
            .find_one(doc! { "_id": id, "user_id": user_id, "deleted_at": null })
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn find_by_public_id(
        &self,
        public_id: &Uuid,
        user_id: &ObjectId,
    ) -> AppResult<Option<VaultItem>> {
        self.col
            .find_one(doc! {
                "public_id": public_id.to_string(),
                "user_id": user_id,
                "deleted_at": null
            })
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// List all non-deleted items for a user, newest first.
    /// `after` is the last seen ObjectId for cursor pagination.
    pub async fn list_for_user(
        &self,
        user_id: &ObjectId,
        after: Option<&ObjectId>,
        limit: u32,
    ) -> AppResult<Vec<VaultItem>> {
        let mut filter = doc! { "user_id": user_id, "deleted_at": null };

        if let Some(cursor_id) = after {
            filter.insert("_id", doc! { "$lt": cursor_id });
        }

        let opts = FindOptions::builder()
            .sort(doc! { "_id": -1 })
            .limit((limit + 1) as i64)   // +1 to detect has_more
            .build();

        self.col
            .find(filter)
            .with_options(opts)
            .await
            .map_err(|e| AppError::Database(e.to_string()))?
            .try_collect::<Vec<_>>()
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// List items in a specific collection
    pub async fn list_by_collection(
        &self,
        collection_id: &ObjectId,
        user_id: &ObjectId,
        limit: u32,
    ) -> AppResult<Vec<VaultItem>> {
        let opts = FindOptions::builder()
            .sort(doc! { "updated_at": -1 })
            .limit(limit as i64)
            .build();

        self.col
            .find(doc! {
                "user_id": user_id,
                "collection_ids": collection_id,
                "deleted_at": null
            })
            .with_options(opts)
            .await
            .map_err(|e| AppError::Database(e.to_string()))?
            .try_collect()
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// List trashed items
    pub async fn list_trash(&self, user_id: &ObjectId) -> AppResult<Vec<VaultItem>> {
        self.col
            .find(doc! { "user_id": user_id, "deleted_at": { "$ne": null } })
            .await
            .map_err(|e| AppError::Database(e.to_string()))?
            .try_collect()
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn insert(&self, item: &VaultItem) -> AppResult<ObjectId> {
        let result = self.col
            .insert_one(item)
            .await
            .map_err(|e| AppError::Database(e.to_string()))?;

        result
            .inserted_id
            .as_object_id()
            .ok_or_else(|| AppError::Database("Insert returned no ObjectId".into()))
    }

    pub async fn update(
        &self,
        id: &ObjectId,
        user_id: &ObjectId,
        encrypted_data: &str,
        name: &str,
        notes: Option<&str>,
        tags: Vec<String>,
        favourite: bool,
    ) -> AppResult<Option<VaultItem>> {
        let now = bson::DateTime::from_chrono(Utc::now());
        let opts = FindOneAndUpdateOptions::builder()
            .return_document(ReturnDocument::After)
            .build();

        self.col
            .find_one_and_update(
                doc! { "_id": id, "user_id": user_id, "deleted_at": null },
                doc! {
                    "$set": {
                        "encrypted_data":  encrypted_data,
                        "name":            name,
                        "notes":           notes,
                        "tags":            &tags,
                        "favourite":       favourite,
                        "revision_date":   &now,
                        "updated_at":      &now,
                    }
                },
            )
            .with_options(opts)
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Toggle favourite without touching the ciphertext
    pub async fn set_favourite(
        &self,
        id: &ObjectId,
        user_id: &ObjectId,
        favourite: bool,
    ) -> AppResult<()> {
        let now = bson::DateTime::from_chrono(Utc::now());
        self.col
            .update_one(
                doc! { "_id": id, "user_id": user_id },
                doc! { "$set": { "favourite": favourite, "updated_at": &now } },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Soft delete — move to trash
    pub async fn soft_delete(&self, id: &ObjectId, user_id: &ObjectId) -> AppResult<()> {
        let now = bson::DateTime::from_chrono(Utc::now());
        self.col
            .update_one(
                doc! { "_id": id, "user_id": user_id, "deleted_at": null },
                doc! { "$set": { "deleted_at": &now, "updated_at": &now } },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Restore from trash
    pub async fn restore(&self, id: &ObjectId, user_id: &ObjectId) -> AppResult<()> {
        let now = bson::DateTime::from_chrono(Utc::now());
        self.col
            .update_one(
                doc! { "_id": id, "user_id": user_id },
                doc! { "$set": { "deleted_at": null, "updated_at": &now } },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Permanent delete — unrecoverable
    pub async fn permanent_delete(&self, id: &ObjectId, user_id: &ObjectId) -> AppResult<()> {
        self.col
            .delete_one(doc! { "_id": id, "user_id": user_id })
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }
}
