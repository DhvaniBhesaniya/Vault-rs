use futures::TryStreamExt;
use mongodb::{
    bson::{doc, oid::ObjectId},
    options::FindOptions,
    Collection,
};

use crate::{
    error::{AppError, AppResult},
    models::audit_log::AuditLog,
};

/// Write-only repository — audit records are never mutated or deleted by the app.
/// MongoDB TTL index removes records after 90 days automatically.
/// Write-only repository — audit records are never mutated or deleted by the app.
/// MongoDB TTL index removes records after 90 days automatically.
#[derive(Clone)]
pub struct AuditRepo {
    col: Collection<AuditLog>,
}

impl AuditRepo {
    pub fn new(col: Collection<AuditLog>) -> Self { Self { col } }

    /// Fire-and-forget audit insert.  Errors are logged but not propagated —
    /// an audit failure must never abort the user's request.
    pub async fn record(&self, log: AuditLog) {
        if let Err(e) = self.col.insert_one(&log).await {
            tracing::error!(error = %e, event = ?log.event_type, "Failed to write audit log");
        }
    }

    /// Paginated audit log for a single user
    pub async fn list_for_user(
        &self,
        user_id: &ObjectId,
        limit: u32,
        skip: u64,
    ) -> AppResult<Vec<AuditLog>> {
        let opts = FindOptions::builder()
            .sort(doc! { "created_at": -1 })
            .limit(limit as i64)
            .skip(skip)
            .build();

        self.col
            .find(doc! { "actor_user_id": user_id })
            .with_options(opts)
            .await
            .map_err(|e| AppError::Database(e.to_string()))?
            .try_collect()
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Paginated audit log for an organisation
    pub async fn list_for_org(
        &self,
        org_id: &ObjectId,
        limit: u32,
        skip: u64,
    ) -> AppResult<Vec<AuditLog>> {
        let opts = FindOptions::builder()
            .sort(doc! { "created_at": -1 })
            .limit(limit as i64)
            .skip(skip)
            .build();

        self.col
            .find(doc! { "organization_id": org_id })
            .with_options(opts)
            .await
            .map_err(|e| AppError::Database(e.to_string()))?
            .try_collect()
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }
}
