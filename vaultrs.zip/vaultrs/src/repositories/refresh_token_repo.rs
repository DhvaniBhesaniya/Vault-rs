// ── refresh_token_repo.rs ─────────────────────────────────────────────────────
use chrono::Utc;
use mongodb::{bson::{doc, oid::ObjectId}, Collection};

use crate::{
    error::{AppError, AppResult},
    models::refresh_token::RefreshToken,
};

pub struct RefreshTokenRepo {
    col: Collection<RefreshToken>,
}

impl RefreshTokenRepo {
    pub fn new(col: Collection<RefreshToken>) -> Self { Self { col } }

    pub async fn find_by_hash(&self, token_hash: &str) -> AppResult<Option<RefreshToken>> {
        self.col
            .find_one(doc! { "token_hash": token_hash })
            .await
            .map_err(|e| AppError::Database(e.to_string()))
    }

    pub async fn insert(&self, token: &RefreshToken) -> AppResult<()> {
        self.col
            .insert_one(token)
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Revoke a single token
    pub async fn revoke(&self, token_hash: &str) -> AppResult<()> {
        let now = bson::DateTime::from_chrono(Utc::now());
        self.col
            .update_one(
                doc! { "token_hash": token_hash },
                doc! { "$set": { "revoked_at": now } },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Revoke entire rotation family (theft detection)
    pub async fn revoke_family(&self, family_id: &str) -> AppResult<()> {
        let now = bson::DateTime::from_chrono(Utc::now());
        self.col
            .update_many(
                doc! { "family_id": family_id, "revoked_at": null },
                doc! { "$set": { "revoked_at": now } },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }

    /// Revoke all tokens for a user (logout-all)
    pub async fn revoke_all_for_user(&self, user_id: &ObjectId) -> AppResult<()> {
        let now = bson::DateTime::from_chrono(Utc::now());
        self.col
            .update_many(
                doc! { "user_id": user_id, "revoked_at": null },
                doc! { "$set": { "revoked_at": now } },
            )
            .await
            .map(|_| ())
            .map_err(|e| AppError::Database(e.to_string()))
    }
}
