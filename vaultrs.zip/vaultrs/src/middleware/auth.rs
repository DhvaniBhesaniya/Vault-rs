//! JWT authentication middleware.
//!
//! Extracts the Bearer token from the Authorization header, verifies its
//! RS256 signature and expiry, then validates the `security_stamp` against
//! the database (so password changes invalidate all live tokens instantly).
//!
//! On success it injects `AuthUser` into request extensions so handlers
//! can extract it with `Extension<AuthUser>`.

use axum::{
    extract::{Request, State},
    middleware::Next,
    response::Response,
};
use mongodb::bson::{doc, oid::ObjectId};
use std::str::FromStr;

use crate::{
    error::{AppError, AppResult},
    models::{common::SystemRole, user::User},
    state::AppState,
};

/// Authenticated user context — injected into request extensions after
/// successful JWT verification.
#[derive(Debug, Clone)]
pub struct AuthUser {
    pub user_id:        ObjectId,
    pub public_id:      String,
    pub email:          String,
    pub roles:          Vec<SystemRole>,
    pub security_stamp: String,
}

impl AuthUser {
    pub fn is_super_admin(&self) -> bool {
        self.roles.contains(&SystemRole::SuperAdmin)
    }

    pub fn require_super_admin(&self) -> AppResult<()> {
        if self.is_super_admin() { Ok(()) } else { Err(AppError::Forbidden) }
    }
}

/// Axum middleware that enforces JWT authentication on protected routes.
pub async fn require_auth(
    State(state): State<AppState>,
    mut req: Request,
    next: Next,
) -> Result<Response, AppError> {
    let token = extract_bearer(req.headers())?;
    let claims = state.jwt.verify(&token)?;

    // Fetch user and validate security_stamp to catch post-password-change tokens
    let user_id = ObjectId::from_str(&claims.sub)
        .map_err(|_| AppError::Unauthorized)?;

    let user: Option<User> = state
        .db
        .users()
        .find_one(doc! { "_id": &user_id, "deleted_at": null })
        .await
        .map_err(|e| AppError::Database(e.to_string()))?;

    let user = user.ok_or(AppError::Unauthorized)?;

    if user.security_stamp.to_string() != claims.security_stamp {
        return Err(AppError::Unauthorized);
    }

    if user.is_locked() {
        let until = user.locked_until.unwrap().to_rfc3339();
        return Err(AppError::AccountLocked(until));
    }

    let auth_user = AuthUser {
        user_id:        user_id,
        public_id:      claims.sub,
        email:          claims.email,
        roles:          claims.roles,
        security_stamp: claims.security_stamp,
    };

    req.extensions_mut().insert(auth_user);
    Ok(next.run(req).await)
}

/// Extract `Bearer <token>` from the Authorization header.
fn extract_bearer(headers: &axum::http::HeaderMap) -> AppResult<String> {
    let header = headers
        .get(axum::http::header::AUTHORIZATION)
        .and_then(|v| v.to_str().ok())
        .ok_or(AppError::Unauthorized)?;

    header
        .strip_prefix("Bearer ")
        .map(|t| t.to_string())
        .ok_or(AppError::Unauthorized)
}
