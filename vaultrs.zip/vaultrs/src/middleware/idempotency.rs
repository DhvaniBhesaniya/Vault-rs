//! Idempotency middleware.
//!
//! For any mutating request that includes an `Idempotency-Key` header:
//!   1. Check MongoDB for an existing record with (key, user_id).
//!   2. If found  → return the stored response verbatim (replay).
//!   3. If absent → run the handler, then store the result.
//!
//! The record TTL is 24 hours (MongoDB TTL index on `created_at`).

use axum::{
    body::Body,
    extract::{Request, State},
    http::{Method, StatusCode},
    middleware::Next,
    response::Response,
};
use bytes::Bytes;
use chrono::Utc;
use http_body_util::BodyExt;
use mongodb::bson::doc;

use crate::{
    middleware::auth::AuthUser,
    models::idempotency::IdempotencyRecord,
    state::AppState,
    error::AppError,
};

const IDEMPOTENCY_HEADER: &str = "Idempotency-Key";
const MAX_KEY_LEN: usize = 256;

/// Methods that support idempotency keys
fn is_mutating(method: &Method) -> bool {
    matches!(*method, Method::POST | Method::PUT | Method::PATCH | Method::DELETE)
}

pub async fn idempotency_layer(
    State(state): State<AppState>,
    req: Request,
    next: Next,
) -> Result<Response, AppError> {
    // Only apply to mutating methods
    if !is_mutating(req.method()) {
        return Ok(next.run(req).await);
    }

    // Extract key from header (optional — if absent, skip idempotency)
    let key = match req.headers().get(IDEMPOTENCY_HEADER).and_then(|v| v.to_str().ok()) {
        Some(k) if k.len() <= MAX_KEY_LEN => k.to_string(),
        Some(_) => return Err(AppError::BadRequest("Idempotency-Key too long (max 256 chars)".into())),
        None    => return Ok(next.run(req).await),
    };

    // Require auth context (idempotency is scoped per user)
    let auth_user = req.extensions().get::<AuthUser>().cloned();
    let user_id   = match &auth_user {
        Some(u) => u.user_id,
        None    => return Ok(next.run(req).await),
    };

    let path   = req.uri().path().to_string();
    let method = req.method().to_string();

    // ── Check for existing record ────────────────────────────────────────────
    let existing: Option<IdempotencyRecord> = state
        .db
        .idempotency_records()
        .find_one(doc! { "_id": &key, "user_id": &user_id })
        .await
        .map_err(|e| AppError::Database(e.to_string()))?;

    if let Some(record) = existing {
        // Replay stored response
        let body = Body::from(record.response_body);
        let mut response = Response::builder()
            .status(record.status_code)
            .header("Content-Type", "application/json")
            .header("X-Idempotency-Replayed", "true")
            .body(body)
            .map_err(|_| AppError::Crypto)?; // reuse internal error
        return Ok(response);
    }

    // ── Run the actual handler ───────────────────────────────────────────────
    let response = next.run(req).await;
    let status   = response.status().as_u16();

    // Only store successful and 4xx responses (not 5xx — those may be retried)
    if status < 500 {
        let (parts, body) = response.into_parts();
        let bytes: Bytes  = body.collect().await
            .map(|c| c.to_bytes())
            .unwrap_or_default();

        let body_str = String::from_utf8_lossy(&bytes).to_string();

        let record = IdempotencyRecord {
            key:           key.clone(),
            user_id,
            method,
            path,
            status_code:   status,
            response_body: body_str.clone(),
            created_at:    Utc::now(),
        };

        // Best-effort insert — if it fails (e.g. duplicate key race), that's fine
        let _ = state.db.idempotency_records().insert_one(record).await;

        let rebuilt = Response::from_parts(parts, Body::from(bytes));
        Ok(rebuilt)
    } else {
        Ok(response)
    }
}
