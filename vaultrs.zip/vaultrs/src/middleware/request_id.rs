use axum::{extract::Request, middleware::Next, response::Response};
use uuid::Uuid;

pub const REQUEST_ID_HEADER: &str = "X-Request-Id";

/// Attach a unique request ID to every request and response.
/// Handlers can extract it for logging correlation.
pub async fn request_id_layer(mut req: Request, next: Next) -> Response {
    let id = req
        .headers()
        .get(REQUEST_ID_HEADER)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_string();

    let id = if id.is_empty() {
        Uuid::new_v4().to_string()
    } else {
        id
    };

    req.extensions_mut().insert(RequestId(id.clone()));

    let mut response = next.run(req).await;
    response.headers_mut().insert(
        REQUEST_ID_HEADER,
        id.parse().unwrap_or_default(),
    );
    response
}

#[derive(Clone, Debug)]
pub struct RequestId(pub String);
