//! In-process rate limiter using `governor` (token-bucket / GCRA algorithm).
//!
//! Each "bucket" is keyed by a string (IP address, user ID, or composite).
//! Limits reset automatically; no background cleanup is needed because
//! `governor`'s DashMap backend handles eviction.
//!
//! For a single-process deployment this replaces Redis entirely.
//! If you later need multi-instance rate limiting, swap the store for a
//! Redis-backed one without changing any calling code.

use std::{
    num::NonZeroU32,
    sync::Arc,
    time::Duration,
};

use dashmap::DashMap;
use governor::{
    clock::DefaultClock,
    middleware::NoOpMiddleware,
    state::{InMemoryState, NotKeyed},
    Quota, RateLimiter as GovernorRL,
};

type Limiter = GovernorRL<NotKeyed, InMemoryState, DefaultClock, NoOpMiddleware>;

/// A named bucket with its own quota
struct Bucket {
    limiter: Limiter,
    /// How long to tell clients to wait on rejection (seconds)
    retry_after: u64,
}

/// Collection of named rate-limit buckets.
/// Create one instance and share it via `Arc<RateLimiter>`.
pub struct RateLimiter {
    /// key → per-key limiters
    buckets: DashMap<String, Arc<Limiter>>,
    /// Default quota applied when no specific rule matches
    default_quota: Quota,
    default_retry_after: u64,
}

impl RateLimiter {
    pub fn new() -> Arc<Self> {
        Arc::new(Self {
            buckets:            DashMap::new(),
            // Global fallback: 200 req / min per IP
            default_quota:      Quota::per_minute(NonZeroU32::new(200).unwrap()),
            default_retry_after: 60,
        })
    }

    // ── Specific limit constructors ──────────────────────────────────────────

    fn login_limiter() -> Limiter {
        // 5 attempts per 5 minutes
        GovernorRL::direct(Quota::with_period(Duration::from_secs(60))
            .unwrap()
            .allow_burst(NonZeroU32::new(5).unwrap()))
    }

    fn register_limiter() -> Limiter {
        // 10 per hour
        GovernorRL::direct(Quota::per_hour(NonZeroU32::new(10).unwrap()))
    }

    fn vault_read_limiter() -> Limiter {
        // 120 per minute
        GovernorRL::direct(Quota::per_minute(NonZeroU32::new(120).unwrap()))
    }

    fn vault_write_limiter() -> Limiter {
        // 30 per minute
        GovernorRL::direct(Quota::per_minute(NonZeroU32::new(30).unwrap()))
    }

    fn vault_delete_limiter() -> Limiter {
        // 10 per minute
        GovernorRL::direct(Quota::per_minute(NonZeroU32::new(10).unwrap()))
    }

    fn two_factor_limiter() -> Limiter {
        // 10 per 10 minutes
        GovernorRL::direct(Quota::with_period(Duration::from_secs(600))
            .unwrap()
            .allow_burst(NonZeroU32::new(10).unwrap()))
    }

    fn default_limiter(&self) -> Limiter {
        GovernorRL::direct(self.default_quota)
    }

    // ── Check methods ────────────────────────────────────────────────────────

    /// Check (and consume) one token from the appropriate bucket.
    ///
    /// Returns `Ok(())` if allowed, `Err(retry_after_seconds)` if limited.
    pub fn check(&self, endpoint: RateEndpoint, key: &str) -> Result<(), u64> {
        let bucket_key = format!("{}:{}", endpoint.prefix(), key);

        // Get-or-create the per-key limiter
        let limiter = self.buckets
            .entry(bucket_key)
            .or_insert_with(|| Arc::new(self.make_limiter(endpoint)))
            .clone();

        limiter
            .check()
            .map(|_| ())
            .map_err(|_| endpoint.retry_after())
    }

    fn make_limiter(&self, endpoint: RateEndpoint) -> Limiter {
        match endpoint {
            RateEndpoint::Login       => Self::login_limiter(),
            RateEndpoint::Register    => Self::register_limiter(),
            RateEndpoint::TwoFactor   => Self::two_factor_limiter(),
            RateEndpoint::VaultRead   => Self::vault_read_limiter(),
            RateEndpoint::VaultWrite  => Self::vault_write_limiter(),
            RateEndpoint::VaultDelete => Self::vault_delete_limiter(),
            RateEndpoint::Default     => self.default_limiter(),
        }
    }
}

#[derive(Copy, Clone)]
pub enum RateEndpoint {
    Login,
    Register,
    TwoFactor,
    VaultRead,
    VaultWrite,
    VaultDelete,
    Default,
}

impl RateEndpoint {
    fn prefix(self) -> &'static str {
        match self {
            Self::Login       => "login",
            Self::Register    => "register",
            Self::TwoFactor   => "2fa",
            Self::VaultRead   => "vault_read",
            Self::VaultWrite  => "vault_write",
            Self::VaultDelete => "vault_delete",
            Self::Default     => "default",
        }
    }

    fn retry_after(self) -> u64 {
        match self {
            Self::Login       => 300,  // 5 min
            Self::Register    => 3600, // 1 hour
            Self::TwoFactor   => 600,  // 10 min
            Self::VaultRead   => 60,
            Self::VaultWrite  => 60,
            Self::VaultDelete => 60,
            Self::Default     => 60,
        }
    }
}
