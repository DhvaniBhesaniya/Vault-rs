use std::net::SocketAddr;
use anyhow::{Context, Result};

#[derive(Debug, Clone)]
pub struct Config {
    pub host: String,
    pub port: u16,
    pub app_env: AppEnv,

    // MongoDB
    pub mongodb_uri: String,
    pub mongodb_db: String,

    // JWT
    pub jwt_private_key: String,   // PEM contents, loaded from file
    pub jwt_public_key: String,
    pub jwt_access_expiry_seconds: u64,
    pub jwt_refresh_expiry_days: u64,

    // Argon2id (server-side)
    pub argon2_memory_kib: u32,
    pub argon2_iterations: u32,
    pub argon2_parallelism: u32,

    // Security
    pub allowed_origins: Vec<String>,
    pub max_login_attempts: u32,
    pub lockout_duration_minutes: u64,
    pub require_email_verification: bool,
}

#[derive(Debug, Clone, PartialEq)]
pub enum AppEnv {
    Development,
    Production,
}

impl Config {
    pub fn from_env() -> Result<Self> {
        let private_key_path = env_var("JWT_PRIVATE_KEY_PATH")?;
        let public_key_path  = env_var("JWT_PUBLIC_KEY_PATH")?;

        let jwt_private_key = std::fs::read_to_string(&private_key_path)
            .with_context(|| format!("Cannot read JWT private key from {}", private_key_path))?;
        let jwt_public_key = std::fs::read_to_string(&public_key_path)
            .with_context(|| format!("Cannot read JWT public key from {}", public_key_path))?;

        let allowed_origins = env_var("ALLOWED_ORIGINS")
            .unwrap_or_else(|_| "http://localhost:3000".into())
            .split(',')
            .map(|s| s.trim().to_string())
            .collect();

        let app_env = match env_var("APP_ENV").as_deref() {
            Ok("production") => AppEnv::Production,
            _                => AppEnv::Development,
        };

        Ok(Self {
            host: env_var("HOST").unwrap_or_else(|_| "0.0.0.0".into()),
            port: env_var("PORT")
                .unwrap_or_else(|_| "8080".into())
                .parse()
                .context("PORT must be a valid u16")?,
            app_env,

            mongodb_uri: env_var("MONGODB_URI")?,
            mongodb_db:  env_var("MONGODB_DB")?,

            jwt_private_key,
            jwt_public_key,
            jwt_access_expiry_seconds: env_var("JWT_ACCESS_EXPIRY_SECONDS")
                .unwrap_or_else(|_| "900".into())
                .parse()
                .context("JWT_ACCESS_EXPIRY_SECONDS must be u64")?,
            jwt_refresh_expiry_days: env_var("JWT_REFRESH_EXPIRY_DAYS")
                .unwrap_or_else(|_| "30".into())
                .parse()
                .context("JWT_REFRESH_EXPIRY_DAYS must be u64")?,

            argon2_memory_kib:  env_var("ARGON2_MEMORY_KIB")
                .unwrap_or_else(|_| "65536".into()).parse().context("ARGON2_MEMORY_KIB")?,
            argon2_iterations:  env_var("ARGON2_ITERATIONS")
                .unwrap_or_else(|_| "3".into()).parse().context("ARGON2_ITERATIONS")?,
            argon2_parallelism: env_var("ARGON2_PARALLELISM")
                .unwrap_or_else(|_| "4".into()).parse().context("ARGON2_PARALLELISM")?,

            allowed_origins,
            max_login_attempts: env_var("MAX_LOGIN_ATTEMPTS")
                .unwrap_or_else(|_| "5".into()).parse().context("MAX_LOGIN_ATTEMPTS")?,
            lockout_duration_minutes: env_var("LOCKOUT_DURATION_MINUTES")
                .unwrap_or_else(|_| "15".into()).parse().context("LOCKOUT_DURATION_MINUTES")?,
            require_email_verification: env_var("REQUIRE_EMAIL_VERIFICATION")
                .unwrap_or_else(|_| "false".into())
                .parse()
                .context("REQUIRE_EMAIL_VERIFICATION must be bool")?,
        })
    }

    pub fn socket_addr(&self) -> Result<SocketAddr> {
        format!("{}:{}", self.host, self.port)
            .parse()
            .context("Invalid HOST:PORT combination")
    }

    pub fn is_production(&self) -> bool {
        self.app_env == AppEnv::Production
    }
}

fn env_var(name: &str) -> Result<String> {
    std::env::var(name).with_context(|| format!("Missing environment variable: {}", name))
}
