use chrono::Utc;
use mongodb::bson::{doc, oid::ObjectId};

use crate::{
    db::Db,
    models::audit_log::{AuditEvent, AuditLog},
    repositories::audit_repo::AuditRepo,
};

#[derive(Clone)]
pub struct AuditService {
    repo: AuditRepo,
}

impl AuditService {
    pub fn new(db: &Db) -> Self {
        Self { repo: AuditRepo::new(db.audit_logs()) }
    }

    /// Record an audit event. Fire-and-forget — never fails the caller.
    pub fn record(
        &self,
        event:       AuditEvent,
        actor_id:    Option<ObjectId>,
        target_type: &str,
        target_id:   &str,
        ip:          &str,
        user_agent:  &str,
    ) {
        let log = AuditLog {
            id:              None,
            actor_user_id:   actor_id,
            organization_id: None,
            event_type:      event,
            target_type:     target_type.to_string(),
            target_id:       target_id.to_string(),
            ip_address:      ip.to_string(),
            user_agent:      user_agent.to_string(),
            idempotency_key: None,
            metadata:        doc! {},
            created_at:      Utc::now(),
        };

        let repo = self.repo.clone();
        tokio::spawn(async move {
            repo.record(log).await;
        });
    }
}
