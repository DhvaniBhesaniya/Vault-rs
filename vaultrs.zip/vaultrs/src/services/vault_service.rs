use chrono::Utc;
use mongodb::bson::oid::ObjectId;
use std::str::FromStr;
use uuid::Uuid;

use crate::{
    db::Db,
    dto::vault_dto::{
        CollectionResponse, CreateCollectionRequest, CreateItemRequest,
        UpdateItemRequest, VaultItemListResponse, VaultItemResponse,
    },
    error::{AppError, AppResult},
    models::{
        collection::VaultCollection,
        vault_item::VaultItem,
    },
    repositories::{
        collection_repo::CollectionRepo,
        vault_item_repo::VaultItemRepo,
    },
};

pub struct VaultService {
    item_repo:       VaultItemRepo,
    collection_repo: CollectionRepo,
}

impl VaultService {
    pub fn new(db: &Db) -> Self {
        Self {
            item_repo:       VaultItemRepo::new(db.vault_items()),
            collection_repo: CollectionRepo::new(db.collections()),
        }
    }

    // ── Items ─────────────────────────────────────────────────────────────────

    pub async fn create_item(
        &self,
        user_id: &ObjectId,
        req: CreateItemRequest,
    ) -> AppResult<VaultItemResponse> {
        let collection_ids: Vec<ObjectId> = req
            .collection_ids
            .unwrap_or_default()
            .iter()
            .filter_map(|s| ObjectId::from_str(s).ok())
            .collect();

        let now  = Utc::now();
        let item = VaultItem {
            id:                  None,
            public_id:           Uuid::new_v4(),
            user_id:             *user_id,
            organization_id:     None,
            collection_ids,
            item_type:           req.item_type,
            name:                req.name,
            encrypted_data:      req.encrypted_data,
            notes:               req.notes,
            custom_fields:       req.custom_fields.unwrap_or_default(),
            tags:                req.tags.unwrap_or_default(),
            favourite:           req.favourite.unwrap_or(false),
            reprompt:            req.reprompt.unwrap_or(false),
            revision_date:       now,
            password_changed_at: Some(now),
            created_at:          now,
            updated_at:          now,
            deleted_at:          None,
        };

        self.item_repo.insert(&item).await?;
        Ok(item_to_response(&item))
    }

    pub async fn get_item(
        &self,
        item_public_id: &str,
        user_id: &ObjectId,
    ) -> AppResult<VaultItemResponse> {
        let uuid = parse_uuid(item_public_id)?;
        let item = self.item_repo
            .find_by_public_id(&uuid, user_id)
            .await?
            .ok_or_else(|| AppError::NotFound("Item".into()))?;
        Ok(item_to_response(&item))
    }

    pub async fn list_items(
        &self,
        user_id: &ObjectId,
        after: Option<&str>,
        limit: u32,
    ) -> AppResult<VaultItemListResponse> {
        let after_id = after
            .map(|s| ObjectId::from_str(s))
            .transpose()
            .map_err(|_| AppError::BadRequest("Invalid cursor".into()))?;

        let mut items = self.item_repo
            .list_for_user(user_id, after_id.as_ref(), limit)
            .await?;

        let has_more    = items.len() > limit as usize;
        let next_cursor = if has_more {
            items.truncate(limit as usize);
            items.last().and_then(|i| i.id).map(|oid| oid.to_hex())
        } else {
            None
        };

        Ok(VaultItemListResponse {
            data:        items.iter().map(item_to_response).collect(),
            has_more,
            next_cursor,
        })
    }

    pub async fn update_item(
        &self,
        item_public_id: &str,
        user_id: &ObjectId,
        req: UpdateItemRequest,
    ) -> AppResult<VaultItemResponse> {
        let uuid    = parse_uuid(item_public_id)?;
        let item    = self.item_repo
            .find_by_public_id(&uuid, user_id)
            .await?
            .ok_or_else(|| AppError::NotFound("Item".into()))?;
        let item_id = item.id.unwrap();

        let updated = self.item_repo
            .update(
                &item_id,
                user_id,
                &req.encrypted_data,
                &req.name,
                req.notes.as_deref(),
                req.tags.unwrap_or_default(),
                req.favourite.unwrap_or(item.favourite),
            )
            .await?
            .ok_or_else(|| AppError::NotFound("Item".into()))?;

        Ok(item_to_response(&updated))
    }

    pub async fn set_favourite(
        &self,
        item_public_id: &str,
        user_id: &ObjectId,
        favourite: bool,
    ) -> AppResult<()> {
        let uuid    = parse_uuid(item_public_id)?;
        let item    = self.item_repo
            .find_by_public_id(&uuid, user_id)
            .await?
            .ok_or_else(|| AppError::NotFound("Item".into()))?;
        self.item_repo.set_favourite(&item.id.unwrap(), user_id, favourite).await
    }

    pub async fn delete_item(
        &self,
        item_public_id: &str,
        user_id: &ObjectId,
    ) -> AppResult<()> {
        let uuid    = parse_uuid(item_public_id)?;
        let item    = self.item_repo
            .find_by_public_id(&uuid, user_id)
            .await?
            .ok_or_else(|| AppError::NotFound("Item".into()))?;
        self.item_repo.soft_delete(&item.id.unwrap(), user_id).await
    }

    pub async fn restore_item(
        &self,
        item_public_id: &str,
        user_id: &ObjectId,
    ) -> AppResult<()> {
        let uuid = parse_uuid(item_public_id)?;
        // find_by_public_id filters out deleted — use raw query for restore
        let items = self.item_repo.list_trash(user_id).await?;
        let item  = items
            .iter()
            .find(|i| i.public_id == uuid)
            .ok_or_else(|| AppError::NotFound("Item in trash".into()))?;
        self.item_repo.restore(&item.id.unwrap(), user_id).await
    }

    pub async fn permanent_delete(
        &self,
        item_public_id: &str,
        user_id: &ObjectId,
    ) -> AppResult<()> {
        let uuid  = parse_uuid(item_public_id)?;
        let items = self.item_repo.list_trash(user_id).await?;
        let item  = items
            .iter()
            .find(|i| i.public_id == uuid)
            .ok_or_else(|| AppError::NotFound("Item in trash".into()))?;
        self.item_repo.permanent_delete(&item.id.unwrap(), user_id).await
    }

    // ── Collections ───────────────────────────────────────────────────────────

    pub async fn create_collection(
        &self,
        user_id: &ObjectId,
        req: CreateCollectionRequest,
    ) -> AppResult<CollectionResponse> {
        let now = Utc::now();
        let col = VaultCollection {
            id:              None,
            public_id:       Uuid::new_v4(),
            user_id:         *user_id,
            organization_id: None,
            name:            req.name,
            hide_passwords:  req.hide_passwords.unwrap_or(false),
            read_only:       req.read_only.unwrap_or(false),
            created_at:      now,
            updated_at:      now,
        };

        self.collection_repo.insert(&col).await?;
        Ok(collection_to_response(&col))
    }

    pub async fn list_collections(
        &self,
        user_id: &ObjectId,
    ) -> AppResult<Vec<CollectionResponse>> {
        let cols = self.collection_repo.list_for_user(user_id).await?;
        Ok(cols.iter().map(collection_to_response).collect())
    }

    pub async fn delete_collection(
        &self,
        collection_public_id: &str,
        user_id: &ObjectId,
    ) -> AppResult<()> {
        let uuid = parse_uuid(collection_public_id)?;
        let cols = self.collection_repo.list_for_user(user_id).await?;
        let col  = cols
            .iter()
            .find(|c| c.public_id == uuid)
            .ok_or_else(|| AppError::NotFound("Collection".into()))?;
        self.collection_repo.delete(&col.id.unwrap(), user_id).await
    }
}

// ── Mapping helpers ──────────────────────────────────────────────────────────

fn item_to_response(item: &VaultItem) -> VaultItemResponse {
    VaultItemResponse {
        id:             item.public_id.to_string(),
        item_type:      item.item_type.clone(),
        name:           item.name.clone(),
        encrypted_data: item.encrypted_data.clone(),
        notes:          item.notes.clone(),
        custom_fields:  item.custom_fields.clone(),
        tags:           item.tags.clone(),
        favourite:      item.favourite,
        reprompt:       item.reprompt,
        collection_ids: item.collection_ids.iter().map(|id| id.to_hex()).collect(),
        revision_date:  item.revision_date.to_rfc3339(),
        created_at:     item.created_at.to_rfc3339(),
        updated_at:     item.updated_at.to_rfc3339(),
    }
}

fn collection_to_response(col: &VaultCollection) -> CollectionResponse {
    CollectionResponse {
        id:             col.public_id.to_string(),
        name:           col.name.clone(),
        hide_passwords: col.hide_passwords,
        read_only:      col.read_only,
        created_at:     col.created_at.to_rfc3339(),
    }
}

fn parse_uuid(s: &str) -> AppResult<Uuid> {
    Uuid::parse_str(s).map_err(|_| AppError::BadRequest("Invalid item ID format".into()))
}
