use chrono::{Duration, Utc};
use mongodb::bson::doc;
use secrecy::Secret;
use uuid::Uuid;

use crate::{
    config::Config,
    crypto::{
        argon2::{hash_password, verify_password, generate_kdf_salt, Argon2Config},
        jwt::JwtKeys,
        keys::{generate_opaque_token, hash_token},
    },
    db::Db,
    dto::auth_dto::{
        KdfParams, LoginRequest, LoginResponse, RegisterRequest, RegisterResponse,
        TokenPair, UserProfile,
    },
    error::{AppError, AppResult},
    models::{
        common::SystemRole,
        refresh_token::RefreshToken,
        user::User,
    },
    repositories::{
        refresh_token_repo::RefreshTokenRepo,
        user_repo::UserRepo,
    },
};

pub struct AuthService<'a> {
    user_repo:    UserRepo,
    token_repo:   RefreshTokenRepo,
    jwt:          &'a JwtKeys,
    config:       &'a Config,
}

impl<'a> AuthService<'a> {
    pub fn new(db: &Db, jwt: &'a JwtKeys, config: &'a Config) -> Self {
        Self {
            user_repo:  UserRepo::new(db.users()),
            token_repo: RefreshTokenRepo::new(db.refresh_tokens()),
            jwt,
            config,
        }
    }

    // ── Register ─────────────────────────────────────────────────────────────

    pub async fn register(
        &self,
        req: RegisterRequest,
        ip: &str,
    ) -> AppResult<RegisterResponse> {
        let email = req.email.trim().to_lowercase();

        if self.user_repo.email_exists(&email).await? {
            return Err(AppError::Conflict("Email already registered".into()));
        }

        let argon_cfg = Argon2Config {
            memory_kib:  self.config.argon2_memory_kib,
            iterations:  self.config.argon2_iterations,
            parallelism: self.config.argon2_parallelism,
        };

        // Hash the client-derived MPH with server-side Argon2id (second layer)
        let mph_secret = Secret::new(req.master_password_hash.clone());
        let server_hash = hash_password(&mph_secret, &argon_cfg)?;

        let now = Utc::now();
        let user = User {
            id:                     None,
            public_id:              Uuid::new_v4(),
            email:                  email.clone(),
            email_verified:         !self.config.require_email_verification,
            master_password_hash:   server_hash,
            master_key_hint:        req.master_key_hint,
            protected_symmetric_key: req.protected_symmetric_key,
            protected_private_key:  None,
            public_key:             None,
            kdf_algorithm:          "argon2id".into(),
            kdf_iterations:         req.kdf_iterations,
            kdf_memory:             req.kdf_memory,
            kdf_parallelism:        req.kdf_parallelism,
            kdf_salt:               req.kdf_salt,
            two_factor_enabled:     false,
            totp_secret_encrypted:  None,
            recovery_code_hashes:   vec![],
            security_stamp:         Uuid::new_v4(),
            roles:                  vec![SystemRole::User],
            failed_login_attempts:  0,
            locked_until:           None,
            created_at:             now,
            updated_at:             now,
            last_login_at:          None,
            deleted_at:             None,
        };

        self.user_repo.insert(&user).await?;
        tracing::info!(email = %email, ip = %ip, "New user registered");

        Ok(RegisterResponse {
            user_id: user.public_id.to_string(),
            email,
        })
    }

    // ── Login step 1: password verification ─────────────────────────────────

    pub async fn login(
        &self,
        req: LoginRequest,
        ip: &str,
        user_agent: &str,
    ) -> AppResult<LoginResponse> {
        let email = req.email.trim().to_lowercase();

        // Find user — use constant-time path even on "not found" to avoid
        // user enumeration via timing differences
        let user = self.user_repo
            .find_by_email(&email)
            .await?
            .ok_or(AppError::InvalidCredentials)?;

        // Check lockout before anything else
        if user.is_locked() {
            let until = user.locked_until.unwrap().to_rfc3339();
            return Err(AppError::AccountLocked(until));
        }

        // Verify MPH against server-side Argon2id hash
        let mph = Secret::new(req.master_password_hash.clone());
        if verify_password(&mph, &user.master_password_hash).is_err() {
            self.handle_failed_login(&user, ip).await?;
            return Err(AppError::InvalidCredentials);
        }

        // Successful password check — reset failure counter
        let uid = user.id.unwrap();
        self.user_repo.record_successful_login(&uid).await?;

        // If 2FA is enabled, issue a short-lived 2FA token instead of full tokens
        if user.two_factor_enabled {
            // In production: store this in MongoDB with short TTL
            // For now: encode user_id + stamp into a short-lived JWT
            let two_factor_token = self.jwt.sign(
                &user.public_id,
                &user.email,
                vec![],
                &user.security_stamp,
                vec![],
            )?;

            return Ok(LoginResponse {
                requires_two_factor:  true,
                two_factor_token:     Some(two_factor_token),
                access_token:         None,
                refresh_token:        None,
                access_token_expires: None,
                user:                 None,
                kdf:                  None,
            });
        }

        // No 2FA — issue full token pair
        let pair = self.issue_token_pair(&user, ip, user_agent).await?;

        tracing::info!(email = %email, ip = %ip, "User logged in");

        Ok(LoginResponse {
            requires_two_factor:  false,
            two_factor_token:     None,
            access_token:         Some(pair.access_token),
            refresh_token:        Some(pair.refresh_token),
            access_token_expires: Some(pair.access_token_expires),
            user:                 Some(pair.user),
            kdf:                  Some(pair.kdf),
        })
    }

    // ── Refresh token rotation ───────────────────────────────────────────────

    pub async fn refresh(
        &self,
        raw_token: &str,
        ip: &str,
        user_agent: &str,
    ) -> AppResult<TokenPair> {
        let token_hash = hash_token(raw_token);

        let stored = self.token_repo
            .find_by_hash(&token_hash)
            .await?
            .ok_or(AppError::Unauthorized)?;

        // Detect double-use (token theft)
        if stored.revoked_at.is_some() {
            tracing::warn!(
                family_id = %stored.family_id,
                "Refresh token reuse detected — revoking entire family"
            );
            self.token_repo.revoke_family(&stored.family_id.to_string()).await?;
            return Err(AppError::Unauthorized);
        }

        if stored.expires_at <= Utc::now() {
            return Err(AppError::Unauthorized);
        }

        // Revoke the old token
        self.token_repo.revoke(&token_hash).await?;

        // Load fresh user record
        let user = self.user_repo
            .find_by_id(&stored.user_id)
            .await?
            .ok_or(AppError::Unauthorized)?;

        // Issue new pair within the same family
        let new_raw      = generate_opaque_token();
        let new_hash     = hash_token(&new_raw);
        let expires_at   = Utc::now() + Duration::days(self.config.jwt_refresh_expiry_days as i64);
        let access_token = self.jwt.sign(
            &user.public_id,
            &user.email,
            user.roles.clone(),
            &user.security_stamp,
            vec![],
        )?;

        let new_token = RefreshToken {
            id:          None,
            user_id:     stored.user_id,
            token_hash:  new_hash,
            family_id:   stored.family_id,   // same family = rotation chain
            device_id:   stored.device_id,
            ip_address:  ip.to_string(),
            user_agent:  user_agent.to_string(),
            expires_at,
            revoked_at:  None,
            created_at:  Utc::now(),
        };
        self.token_repo.insert(&new_token).await?;

        let expires_ts = (Utc::now()
            + Duration::seconds(self.config.jwt_access_expiry_seconds as i64))
            .timestamp();

        Ok(TokenPair {
            access_token,
            refresh_token:        new_raw,
            access_token_expires: expires_ts,
            user:                 self.user_profile(&user),
            kdf:                  self.kdf_params(&user),
        })
    }

    // ── Logout ───────────────────────────────────────────────────────────────

    pub async fn logout(&self, raw_token: &str) -> AppResult<()> {
        let hash = hash_token(raw_token);
        self.token_repo.revoke(&hash).await
    }

    pub async fn logout_all(&self, user_id: &mongodb::bson::oid::ObjectId) -> AppResult<()> {
        self.token_repo.revoke_all_for_user(user_id).await
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    async fn handle_failed_login(&self, user: &User, ip: &str) -> AppResult<()> {
        let uid         = user.id.unwrap();
        let new_count   = self.user_repo.increment_failed_logins(&uid).await?;
        let max         = self.config.max_login_attempts;

        tracing::warn!(
            email = %user.email,
            ip    = %ip,
            attempts = new_count,
            max = max,
            "Failed login attempt"
        );

        if new_count >= max {
            let lock_until = Utc::now()
                + Duration::minutes(self.config.lockout_duration_minutes as i64);
            self.user_repo.lock_account(&uid, lock_until).await?;
            tracing::warn!(email = %user.email, "Account locked after too many failures");
        }

        Ok(())
    }

    async fn issue_token_pair(
        &self,
        user: &User,
        ip: &str,
        user_agent: &str,
    ) -> AppResult<TokenPair> {
        let raw_token  = generate_opaque_token();
        let token_hash = hash_token(&raw_token);
        let expires_at = Utc::now()
            + Duration::days(self.config.jwt_refresh_expiry_days as i64);

        let refresh_record = RefreshToken {
            id:          None,
            user_id:     user.id.unwrap(),
            token_hash,
            family_id:   Uuid::new_v4(),   // fresh family for every new login
            device_id:   Uuid::new_v4().to_string(),
            ip_address:  ip.to_string(),
            user_agent:  user_agent.to_string(),
            expires_at,
            revoked_at:  None,
            created_at:  Utc::now(),
        };
        self.token_repo.insert(&refresh_record).await?;

        let access_token = self.jwt.sign(
            &user.public_id,
            &user.email,
            user.roles.clone(),
            &user.security_stamp,
            vec![],
        )?;

        let expires_ts = (Utc::now()
            + Duration::seconds(self.config.jwt_access_expiry_seconds as i64))
            .timestamp();

        Ok(TokenPair {
            access_token,
            refresh_token:        raw_token,
            access_token_expires: expires_ts,
            user:                 self.user_profile(user),
            kdf:                  self.kdf_params(user),
        })
    }

    fn user_profile(&self, user: &User) -> UserProfile {
        UserProfile {
            user_id:                 user.public_id.to_string(),
            email:                   user.email.clone(),
            email_verified:          user.email_verified,
            two_factor_enabled:      user.two_factor_enabled,
            protected_symmetric_key: user.protected_symmetric_key.clone(),
            kdf:                     self.kdf_params(user),
        }
    }

    fn kdf_params(&self, user: &User) -> KdfParams {
        KdfParams {
            algorithm:   user.kdf_algorithm.clone(),
            iterations:  user.kdf_iterations,
            memory:      user.kdf_memory,
            parallelism: user.kdf_parallelism,
            salt:        user.kdf_salt.clone(),
        }
    }
}
