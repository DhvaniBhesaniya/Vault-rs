use std::sync::Arc;

use crate::{
    config::Config,
    crypto::jwt::JwtKeys,
    db::Db,
    rate_limit::RateLimiter,
};

/// Cloneable handle to all shared application state.
/// Injected into every Axum handler via `Extension<AppState>`.
#[derive(Clone)]
pub struct AppState {
    pub db:           Db,
    pub jwt:          Arc<JwtKeys>,
    pub config:       Arc<Config>,
    pub rate_limiter: Arc<RateLimiter>,
}
