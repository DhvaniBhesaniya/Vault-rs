mod config;
mod crypto;
mod db;
mod dto;
mod error;
mod middleware;
mod models;
mod rate_limit;
mod repositories;
mod routes;
mod services;
mod state;

use std::sync::Arc;
use anyhow::Context;
use tower_http::{
    compression::CompressionLayer,
    cors::{Any, CorsLayer},
    sensitive_headers::SetSensitiveHeadersLayer,
    trace::TraceLayer,
};
use axum::http::{
    header::{AUTHORIZATION, COOKIE},
    Method,
};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt, EnvFilter};

use crate::{
    config::Config,
    crypto::jwt::JwtKeys,
    db::Db,
    rate_limit::RateLimiter,
    state::AppState,
};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // ── Load .env (ignored in production if vars already set) ────────────────
    let _ = dotenvy::dotenv();

    // ── Tracing / structured logging ─────────────────────────────────────────
    tracing_subscriber::registry()
        .with(EnvFilter::try_from_default_env().unwrap_or_else(|_| "info,vaultrs=debug".into()))
        .with(tracing_subscriber::fmt::layer().json())
        .init();

    tracing::info!("Starting VaultRS…");

    // ── Config ───────────────────────────────────────────────────────────────
    let config = Config::from_env().context("Failed to load configuration")?;
    tracing::info!(port = config.port, env = ?config.app_env, "Configuration loaded");

    // ── JWT keys ─────────────────────────────────────────────────────────────
    let jwt = JwtKeys::new(
        &config.jwt_private_key,
        &config.jwt_public_key,
        config.jwt_access_expiry_seconds,
    )
    .context("Failed to initialise JWT keys — check key files exist and are valid RSA PEM")?;

    // ── Database ─────────────────────────────────────────────────────────────
    let db = Db::connect(&config.mongodb_uri, &config.mongodb_db)
        .await
        .context("Failed to connect to MongoDB")?;

    db.create_indexes()
        .await
        .context("Failed to create MongoDB indexes")?;

    // ── Rate limiter (in-process, no external dependency) ────────────────────
    let rate_limiter = RateLimiter::new();

    // ── Shared application state ─────────────────────────────────────────────
    let state = AppState {
        db,
        jwt:          Arc::new(jwt),
        config:       Arc::new(config.clone()),
        rate_limiter,
    };

    // ── CORS ─────────────────────────────────────────────────────────────────
    let cors = CorsLayer::new()
        .allow_methods([Method::GET, Method::POST, Method::PUT, Method::PATCH, Method::DELETE])
        .allow_headers(Any)
        .allow_origin(
            config
                .allowed_origins
                .iter()
                .filter_map(|o| o.parse().ok())
                .collect::<Vec<_>>(),
        );

    // ── Build router with middleware stack ────────────────────────────────────
    let app = routes::build_router(state)
        .layer(cors)
        .layer(CompressionLayer::new())
        .layer(TraceLayer::new_for_http())
        .layer(SetSensitiveHeadersLayer::new([AUTHORIZATION, COOKIE]));

    // ── Bind and serve ────────────────────────────────────────────────────────
    let addr = config.socket_addr()?;
    tracing::info!(addr = %addr, "VaultRS listening");

    let listener = tokio::net::TcpListener::bind(addr)
        .await
        .with_context(|| format!("Cannot bind to {}", addr))?;

    axum::serve(
        listener,
        app.into_make_service_with_connect_info::<std::net::SocketAddr>(),
    )
    .await
    .context("Server error")?;

    Ok(())
}
