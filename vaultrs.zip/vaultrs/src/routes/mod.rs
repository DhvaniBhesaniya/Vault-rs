pub mod auth;
pub mod health;
pub mod vault;

use axum::{
    middleware,
    routing::{delete, get, patch, post, put},
    Router,
};

use crate::{
    middleware::{
        auth::require_auth,
        idempotency::idempotency_layer,
        request_id::request_id_layer,
    },
    state::AppState,
};

pub fn build_router(state: AppState) -> Router {
    // ── Public routes (no auth) ───────────────────────────────────────────────
    let public = Router::new()
        .route("/health",       get(health::health_check))
        .route("/health/ready", get(health::readiness_check))
        .route("/v1/auth/register", post(auth::register))
        .route("/v1/auth/login",    post(auth::login))
        .route("/v1/auth/refresh",  post(auth::refresh))
        .route("/v1/auth/two-factor", post(auth::two_factor));

    // ── Protected routes (require valid JWT) ─────────────────────────────────
    let protected = Router::new()
        // Auth
        .route("/v1/auth/logout",     post(auth::logout))
        .route("/v1/auth/logout-all", post(auth::logout_all))
        .route("/v1/auth/me",         get(auth::me))
        .route("/v1/auth/password",   put(auth::change_password))
        // Vault items
        .route("/v1/vault/items",               get(vault::items::list_items))
        .route("/v1/vault/items",               post(vault::items::create_item))
        .route("/v1/vault/items/:id",           get(vault::items::get_item))
        .route("/v1/vault/items/:id",           put(vault::items::update_item))
        .route("/v1/vault/items/:id",           patch(vault::items::patch_item))
        .route("/v1/vault/items/:id",           delete(vault::items::delete_item))
        .route("/v1/vault/items/:id/restore",   post(vault::items::restore_item))
        .route("/v1/vault/items/:id/permanent", delete(vault::items::permanent_delete))
        // Collections
        .route("/v1/vault/collections",     get(vault::collections::list_collections))
        .route("/v1/vault/collections",     post(vault::collections::create_collection))
        .route("/v1/vault/collections/:id", delete(vault::collections::delete_collection))
        // Apply auth middleware to all protected routes
        .layer(middleware::from_fn_with_state(state.clone(), require_auth))
        // Apply idempotency after auth (needs user context)
        .layer(middleware::from_fn_with_state(state.clone(), idempotency_layer));

    // ── Combine and apply global middleware ───────────────────────────────────
    Router::new()
        .merge(public)
        .merge(protected)
        .layer(middleware::from_fn(request_id_layer))
        .with_state(state)
}
