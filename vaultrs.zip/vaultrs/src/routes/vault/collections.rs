use axum::{
    extract::{Path, State},
    Extension, Json,
};
use validator::Validate;

use crate::{
    dto::{common_dto::MessageResponse, vault_dto::CreateCollectionRequest},
    error::AppResult,
    middleware::auth::AuthUser,
    services::vault_service::VaultService,
    state::AppState,
};

// ── GET /v1/vault/collections ────────────────────────────────────────────────

pub async fn list_collections(
    State(state): State<AppState>,
    Extension(auth): Extension<AuthUser>,
) -> AppResult<Json<serde_json::Value>> {
    let svc  = VaultService::new(&state.db);
    let cols = svc.list_collections(&auth.user_id).await?;
    Ok(Json(serde_json::json!({ "data": cols })))
}

// ── POST /v1/vault/collections ───────────────────────────────────────────────

pub async fn create_collection(
    State(state): State<AppState>,
    Extension(auth): Extension<AuthUser>,
    Json(req): Json<CreateCollectionRequest>,
) -> AppResult<Json<serde_json::Value>> {
    req.validate()?;
    let svc = VaultService::new(&state.db);
    let col = svc.create_collection(&auth.user_id, req).await?;
    Ok(Json(serde_json::to_value(col).unwrap()))
}

// ── DELETE /v1/vault/collections/:id ─────────────────────────────────────────

pub async fn delete_collection(
    State(state): State<AppState>,
    Extension(auth): Extension<AuthUser>,
    Path(id): Path<String>,
) -> AppResult<Json<MessageResponse>> {
    VaultService::new(&state.db)
        .delete_collection(&id, &auth.user_id)
        .await?;
    Ok(Json(MessageResponse::ok("Collection deleted")))
}
