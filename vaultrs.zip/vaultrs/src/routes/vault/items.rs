use axum::{
    extract::{ConnectInfo, Path, Query, State},
    http::HeaderMap,
    Extension, Json,
};
use serde::Deserialize;
use std::net::SocketAddr;
use validator::Validate;

use crate::{
    dto::{
        common_dto::MessageResponse,
        vault_dto::{CreateItemRequest, PatchItemRequest, UpdateItemRequest},
    },
    error::{AppError, AppResult},
    middleware::auth::AuthUser,
    models::audit_log::AuditEvent,
    rate_limit::RateEndpoint,
    services::{audit_service::AuditService, vault_service::VaultService},
    state::AppState,
};

#[derive(Deserialize)]
pub struct ListParams {
    pub after: Option<String>,
    pub limit: Option<u32>,
}

fn ip(headers: &HeaderMap, addr: SocketAddr) -> String {
    headers
        .get("X-Forwarded-For")
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.split(',').next())
        .map(|s| s.trim().to_string())
        .unwrap_or_else(|| addr.ip().to_string())
}

fn ua(headers: &HeaderMap) -> String {
    headers.get("User-Agent")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("unknown")
        .to_string()
}

// ── GET /v1/vault/items ──────────────────────────────────────────────────────

pub async fn list_items(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Extension(auth): Extension<AuthUser>,
    Query(params): Query<ListParams>,
) -> AppResult<Json<serde_json::Value>> {
    let ip_str = ip(&headers, addr);
    state.rate_limiter
        .check(RateEndpoint::VaultRead, &auth.public_id)
        .map_err(|ra| AppError::RateLimited { retry_after: ra })?;

    let limit = params.limit.unwrap_or(50).min(200);
    let svc   = VaultService::new(&state.db);
    let resp  = svc.list_items(&auth.user_id, params.after.as_deref(), limit).await?;

    Ok(Json(serde_json::to_value(resp).unwrap()))
}

// ── POST /v1/vault/items ─────────────────────────────────────────────────────

pub async fn create_item(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Extension(auth): Extension<AuthUser>,
    Json(req): Json<CreateItemRequest>,
) -> AppResult<Json<serde_json::Value>> {
    req.validate()?;

    let ip_str = ip(&headers, addr);
    let ua_str = ua(&headers);

    state.rate_limiter
        .check(RateEndpoint::VaultWrite, &auth.public_id)
        .map_err(|ra| AppError::RateLimited { retry_after: ra })?;

    let svc  = VaultService::new(&state.db);
    let item = svc.create_item(&auth.user_id, req).await?;

    AuditService::new(&state.db).record(
        AuditEvent::VaultItemCreated,
        Some(auth.user_id),
        "vault_item",
        &item.id,
        &ip_str,
        &ua_str,
    );

    Ok(Json(serde_json::to_value(item).unwrap()))
}

// ── GET /v1/vault/items/:id ──────────────────────────────────────────────────

pub async fn get_item(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Extension(auth): Extension<AuthUser>,
    Path(id): Path<String>,
) -> AppResult<Json<serde_json::Value>> {
    let ip_str = ip(&headers, addr);
    let ua_str = ua(&headers);

    state.rate_limiter
        .check(RateEndpoint::VaultRead, &auth.public_id)
        .map_err(|ra| AppError::RateLimited { retry_after: ra })?;

    let svc  = VaultService::new(&state.db);
    let item = svc.get_item(&id, &auth.user_id).await?;

    AuditService::new(&state.db).record(
        AuditEvent::VaultItemViewed,
        Some(auth.user_id),
        "vault_item",
        &item.id,
        &ip_str,
        &ua_str,
    );

    Ok(Json(serde_json::to_value(item).unwrap()))
}

// ── PUT /v1/vault/items/:id ──────────────────────────────────────────────────

pub async fn update_item(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Extension(auth): Extension<AuthUser>,
    Path(id): Path<String>,
    Json(req): Json<UpdateItemRequest>,
) -> AppResult<Json<serde_json::Value>> {
    req.validate()?;

    let ip_str = ip(&headers, addr);
    let ua_str = ua(&headers);

    state.rate_limiter
        .check(RateEndpoint::VaultWrite, &auth.public_id)
        .map_err(|ra| AppError::RateLimited { retry_after: ra })?;

    let svc  = VaultService::new(&state.db);
    let item = svc.update_item(&id, &auth.user_id, req).await?;

    AuditService::new(&state.db).record(
        AuditEvent::VaultItemUpdated,
        Some(auth.user_id),
        "vault_item",
        &item.id,
        &ip_str,
        &ua_str,
    );

    Ok(Json(serde_json::to_value(item).unwrap()))
}

// ── PATCH /v1/vault/items/:id ────────────────────────────────────────────────

pub async fn patch_item(
    State(state): State<AppState>,
    Extension(auth): Extension<AuthUser>,
    Path(id): Path<String>,
    Json(req): Json<PatchItemRequest>,
) -> AppResult<Json<MessageResponse>> {
    let svc = VaultService::new(&state.db);

    if let Some(fav) = req.favourite {
        svc.set_favourite(&id, &auth.user_id, fav).await?;
    }

    Ok(Json(MessageResponse::ok("Item updated")))
}

// ── DELETE /v1/vault/items/:id (soft) ────────────────────────────────────────

pub async fn delete_item(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Extension(auth): Extension<AuthUser>,
    Path(id): Path<String>,
) -> AppResult<Json<MessageResponse>> {
    let ip_str = ip(&headers, addr);
    let ua_str = ua(&headers);

    state.rate_limiter
        .check(RateEndpoint::VaultDelete, &auth.public_id)
        .map_err(|ra| AppError::RateLimited { retry_after: ra })?;

    VaultService::new(&state.db).delete_item(&id, &auth.user_id).await?;

    AuditService::new(&state.db).record(
        AuditEvent::VaultItemDeleted,
        Some(auth.user_id),
        "vault_item",
        &id,
        &ip_str,
        &ua_str,
    );

    Ok(Json(MessageResponse::ok("Item moved to trash")))
}

// ── POST /v1/vault/items/:id/restore ─────────────────────────────────────────

pub async fn restore_item(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Extension(auth): Extension<AuthUser>,
    Path(id): Path<String>,
) -> AppResult<Json<MessageResponse>> {
    let ip_str = ip(&headers, addr);
    let ua_str = ua(&headers);

    VaultService::new(&state.db).restore_item(&id, &auth.user_id).await?;

    AuditService::new(&state.db).record(
        AuditEvent::VaultItemRestored,
        Some(auth.user_id),
        "vault_item",
        &id,
        &ip_str,
        &ua_str,
    );

    Ok(Json(MessageResponse::ok("Item restored from trash")))
}

// ── DELETE /v1/vault/items/:id/permanent ─────────────────────────────────────

pub async fn permanent_delete(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Extension(auth): Extension<AuthUser>,
    Path(id): Path<String>,
) -> AppResult<Json<MessageResponse>> {
    let ip_str = ip(&headers, addr);
    let ua_str = ua(&headers);

    state.rate_limiter
        .check(RateEndpoint::VaultDelete, &auth.public_id)
        .map_err(|ra| AppError::RateLimited { retry_after: ra })?;

    VaultService::new(&state.db).permanent_delete(&id, &auth.user_id).await?;

    AuditService::new(&state.db).record(
        AuditEvent::VaultItemPermanentlyDeleted,
        Some(auth.user_id),
        "vault_item",
        &id,
        &ip_str,
        &ua_str,
    );

    Ok(Json(MessageResponse::ok("Item permanently deleted")))
}
