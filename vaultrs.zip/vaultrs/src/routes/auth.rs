use axum::{
    extract::{ConnectInfo, State},
    http::HeaderMap,
    Extension, Json,
};
use std::net::SocketAddr;
use validator::Validate;

use crate::{
    dto::{
        auth_dto::{
            ChangePasswordRequest, LoginRequest, RefreshRequest,
            RegisterRequest, TwoFactorRequest,
        },
        common_dto::MessageResponse,
    },
    error::{AppError, AppResult},
    middleware::auth::AuthUser,
    models::audit_log::AuditEvent,
    rate_limit::RateEndpoint,
    services::{audit_service::AuditService, auth_service::AuthService},
    state::AppState,
};

fn extract_ip(headers: &HeaderMap, addr: Option<SocketAddr>) -> String {
    // Prefer X-Forwarded-For (set by reverse proxy)
    headers
        .get("X-Forwarded-For")
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.split(',').next())
        .map(|s| s.trim().to_string())
        .or_else(|| addr.map(|a| a.ip().to_string()))
        .unwrap_or_else(|| "unknown".into())
}

fn extract_user_agent(headers: &HeaderMap) -> String {
    headers
        .get("User-Agent")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("unknown")
        .to_string()
}

// ── POST /v1/auth/register ───────────────────────────────────────────────────

pub async fn register(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Json(req): Json<RegisterRequest>,
) -> AppResult<Json<serde_json::Value>> {
    req.validate()?;

    let ip = extract_ip(&headers, Some(addr));

    // Rate-limit by IP
    state
        .rate_limiter
        .check(RateEndpoint::Register, &ip)
        .map_err(|retry_after| AppError::RateLimited { retry_after })?;

    let svc  = AuthService::new(&state.db, &state.jwt, &state.config);
    let resp = svc.register(req, &ip).await?;

    AuditService::new(&state.db).record(
        AuditEvent::UserRegistered,
        None,
        "user",
        &resp.user_id,
        &ip,
        &extract_user_agent(&headers),
    );

    Ok(Json(serde_json::to_value(resp).unwrap()))
}

// ── POST /v1/auth/login ──────────────────────────────────────────────────────

pub async fn login(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Json(req): Json<LoginRequest>,
) -> AppResult<Json<serde_json::Value>> {
    req.validate()?;

    let ip         = extract_ip(&headers, Some(addr));
    let user_agent = extract_user_agent(&headers);

    // Rate-limit login attempts by IP+email composite key
    let rl_key = format!("{}:{}", ip, req.email.to_lowercase());
    state
        .rate_limiter
        .check(RateEndpoint::Login, &rl_key)
        .map_err(|retry_after| AppError::RateLimited { retry_after })?;

    let svc  = AuthService::new(&state.db, &state.jwt, &state.config);
    let resp = svc.login(req, &ip, &user_agent).await;

    match &resp {
        Ok(r) if !r.requires_two_factor => {
            AuditService::new(&state.db).record(
                AuditEvent::UserLogin,
                None,
                "user",
                "",
                &ip,
                &user_agent,
            );
        }
        Err(AppError::InvalidCredentials) => {
            AuditService::new(&state.db).record(
                AuditEvent::UserLoginFailed,
                None,
                "user",
                "",
                &ip,
                &user_agent,
            );
        }
        _ => {}
    }

    let resp = resp?;
    Ok(Json(serde_json::to_value(resp).unwrap()))
}

// ── POST /v1/auth/two-factor ─────────────────────────────────────────────────

pub async fn two_factor(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Json(req): Json<TwoFactorRequest>,
) -> AppResult<Json<serde_json::Value>> {
    let ip = extract_ip(&headers, Some(addr));

    state
        .rate_limiter
        .check(RateEndpoint::TwoFactor, &ip)
        .map_err(|retry_after| AppError::RateLimited { retry_after })?;

    // Verify the two_factor_token (short-lived JWT from step 1)
    let claims = state.jwt.verify(&req.two_factor_token)?;

    // TODO: verify TOTP code against stored (encrypted) secret
    // For now, return a placeholder until TOTP service is wired up
    let _ = req.code;
    let _ = claims;

    Err(AppError::BadRequest("Two-factor verification not yet implemented".into()))
}

// ── POST /v1/auth/refresh ────────────────────────────────────────────────────

pub async fn refresh(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Json(req): Json<RefreshRequest>,
) -> AppResult<Json<serde_json::Value>> {
    let ip         = extract_ip(&headers, Some(addr));
    let user_agent = extract_user_agent(&headers);

    let svc  = AuthService::new(&state.db, &state.jwt, &state.config);
    let pair = svc.refresh(&req.refresh_token, &ip, &user_agent).await?;

    Ok(Json(serde_json::to_value(pair).unwrap()))
}

// ── POST /v1/auth/logout ─────────────────────────────────────────────────────

pub async fn logout(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Extension(auth): Extension<AuthUser>,
    Json(req): Json<RefreshRequest>,
) -> AppResult<Json<MessageResponse>> {
    let ip         = extract_ip(&headers, Some(addr));
    let user_agent = extract_user_agent(&headers);

    let svc = AuthService::new(&state.db, &state.jwt, &state.config);
    svc.logout(&req.refresh_token).await?;

    AuditService::new(&state.db).record(
        AuditEvent::UserLogout,
        Some(auth.user_id),
        "user",
        &auth.public_id,
        &ip,
        &user_agent,
    );

    Ok(Json(MessageResponse::ok("Logged out successfully")))
}

// ── POST /v1/auth/logout-all ─────────────────────────────────────────────────

pub async fn logout_all(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Extension(auth): Extension<AuthUser>,
) -> AppResult<Json<MessageResponse>> {
    let ip         = extract_ip(&headers, Some(addr));
    let user_agent = extract_user_agent(&headers);

    let svc = AuthService::new(&state.db, &state.jwt, &state.config);
    svc.logout_all(&auth.user_id).await?;

    AuditService::new(&state.db).record(
        AuditEvent::UserLogoutAll,
        Some(auth.user_id),
        "user",
        &auth.public_id,
        &ip,
        &user_agent,
    );

    Ok(Json(MessageResponse::ok("All sessions revoked")))
}

// ── GET /v1/auth/me ──────────────────────────────────────────────────────────

pub async fn me(
    State(state): State<AppState>,
    Extension(auth): Extension<AuthUser>,
) -> AppResult<Json<serde_json::Value>> {
    use crate::repositories::user_repo::UserRepo;
    use crate::dto::auth_dto::{KdfParams, UserProfile};

    let repo = UserRepo::new(state.db.users());
    let user = repo
        .find_by_id(&auth.user_id)
        .await?
        .ok_or(AppError::Unauthorized)?;

    let profile = UserProfile {
        user_id:                 user.public_id.to_string(),
        email:                   user.email,
        email_verified:          user.email_verified,
        two_factor_enabled:      user.two_factor_enabled,
        protected_symmetric_key: user.protected_symmetric_key,
        kdf: KdfParams {
            algorithm:   user.kdf_algorithm,
            iterations:  user.kdf_iterations,
            memory:      user.kdf_memory,
            parallelism: user.kdf_parallelism,
            salt:        user.kdf_salt,
        },
    };

    Ok(Json(serde_json::to_value(profile).unwrap()))
}

// ── PUT /v1/auth/password ────────────────────────────────────────────────────

pub async fn change_password(
    State(state): State<AppState>,
    headers: HeaderMap,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    Extension(auth): Extension<AuthUser>,
    Json(req): Json<ChangePasswordRequest>,
) -> AppResult<Json<MessageResponse>> {
    use crate::repositories::user_repo::UserRepo;
    use crate::crypto::argon2::{verify_password, hash_password, Argon2Config};
    use secrecy::Secret;

    let ip         = extract_ip(&headers, Some(addr));
    let user_agent = extract_user_agent(&headers);

    let repo = UserRepo::new(state.db.users());
    let user = repo
        .find_by_id(&auth.user_id)
        .await?
        .ok_or(AppError::Unauthorized)?;

    // Verify current password
    let current_mph = Secret::new(req.current_master_password_hash);
    verify_password(&current_mph, &user.master_password_hash)?;

    // Hash new MPH
    let cfg      = Argon2Config::default();
    let new_mph  = Secret::new(req.new_master_password_hash);
    let new_hash = hash_password(&new_mph, &cfg)?;

    repo.update_password(&auth.user_id, &new_hash, &req.new_protected_symmetric_key)
        .await?;

    // Revoke all refresh tokens (security: old keys can no longer decrypt vault)
    let svc = AuthService::new(&state.db, &state.jwt, &state.config);
    svc.logout_all(&auth.user_id).await?;

    AuditService::new(&state.db).record(
        AuditEvent::UserPasswordChanged,
        Some(auth.user_id),
        "user",
        &auth.public_id,
        &ip,
        &user_agent,
    );

    Ok(Json(MessageResponse::ok("Password updated. Please log in again.")))
}
