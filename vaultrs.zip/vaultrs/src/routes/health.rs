use axum::{extract::State, http::StatusCode, Json};
use mongodb::bson::doc;
use serde_json::{json, Value};

use crate::state::AppState;

pub async fn health_check() -> (StatusCode, Json<Value>) {
    (StatusCode::OK, Json(json!({ "status": "ok", "service": "vaultrs" })))
}

pub async fn readiness_check(State(state): State<AppState>) -> (StatusCode, Json<Value>) {
    // Ping MongoDB
    match state.db.database.run_command(doc! { "ping": 1 }).await {
        Ok(_) => (
            StatusCode::OK,
            Json(json!({ "status": "ready", "mongodb": "up" })),
        ),
        Err(e) => (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(json!({ "status": "not ready", "mongodb": "down", "error": e.to_string() })),
        ),
    }
}
