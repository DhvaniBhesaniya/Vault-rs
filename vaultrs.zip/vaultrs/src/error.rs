use axum::{
    http::StatusCode,
    response::{IntoResponse, Response},
    Json,
};
use serde_json::json;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum AppError {
    // ── Auth ────────────────────────────────────────────────────────────────
    #[error("Invalid credentials")]
    InvalidCredentials,

    #[error("Account locked until {0}")]
    AccountLocked(String),

    #[error("Email not verified")]
    EmailNotVerified,

    #[error("Two-factor authentication required")]
    TwoFactorRequired,

    #[error("Invalid two-factor code")]
    InvalidTwoFactorCode,

    #[error("Token expired or invalid")]
    Unauthorized,

    #[error("Insufficient permissions")]
    Forbidden,

    // ── Resources ────────────────────────────────────────────────────────────
    #[error("{0} not found")]
    NotFound(String),

    #[error("{0} already exists")]
    Conflict(String),

    // ── Input ────────────────────────────────────────────────────────────────
    #[error("Validation error: {0}")]
    Validation(String),

    #[error("Bad request: {0}")]
    BadRequest(String),

    // ── Rate limiting ────────────────────────────────────────────────────────
    #[error("Too many requests. Retry after {retry_after}s")]
    RateLimited { retry_after: u64 },

    // ── Idempotency ──────────────────────────────────────────────────────────
    #[error("Request with this idempotency key is still in flight")]
    IdempotencyConflict,

    // ── Internal ─────────────────────────────────────────────────────────────
    #[error("Database error: {0}")]
    Database(String),

    #[error("Encryption error")]
    Crypto,

    #[error("Internal server error")]
    Internal(#[from] anyhow::Error),
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        let (status, error_type, detail) = match &self {
            AppError::InvalidCredentials       => (StatusCode::UNAUTHORIZED,           "invalid_credentials",       self.to_string()),
            AppError::AccountLocked(_)         => (StatusCode::FORBIDDEN,              "account_locked",            self.to_string()),
            AppError::EmailNotVerified         => (StatusCode::FORBIDDEN,              "email_not_verified",        self.to_string()),
            AppError::TwoFactorRequired        => (StatusCode::FORBIDDEN,              "two_factor_required",       self.to_string()),
            AppError::InvalidTwoFactorCode     => (StatusCode::UNAUTHORIZED,           "invalid_two_factor_code",   self.to_string()),
            AppError::Unauthorized             => (StatusCode::UNAUTHORIZED,           "unauthorized",              self.to_string()),
            AppError::Forbidden                => (StatusCode::FORBIDDEN,              "forbidden",                 self.to_string()),
            AppError::NotFound(_)              => (StatusCode::NOT_FOUND,              "not_found",                 self.to_string()),
            AppError::Conflict(_)              => (StatusCode::CONFLICT,               "conflict",                  self.to_string()),
            AppError::Validation(_)            => (StatusCode::UNPROCESSABLE_ENTITY,   "validation_error",          self.to_string()),
            AppError::BadRequest(_)            => (StatusCode::BAD_REQUEST,            "bad_request",               self.to_string()),
            AppError::RateLimited { .. }       => (StatusCode::TOO_MANY_REQUESTS,      "rate_limited",              self.to_string()),
            AppError::IdempotencyConflict      => (StatusCode::CONFLICT,               "idempotency_conflict",      self.to_string()),
            AppError::Database(_)              => (StatusCode::INTERNAL_SERVER_ERROR,  "database_error",            "An internal database error occurred".into()),
            AppError::Crypto                   => (StatusCode::INTERNAL_SERVER_ERROR,  "crypto_error",              "A cryptographic error occurred".into()),
            AppError::Internal(_)              => (StatusCode::INTERNAL_SERVER_ERROR,  "internal_error",            "An internal server error occurred".into()),
        };

        // Log internal errors
        match &self {
            AppError::Database(e)  => tracing::error!(error = %e, "Database error"),
            AppError::Internal(e)  => tracing::error!(error = %e, "Internal error"),
            AppError::Crypto       => tracing::error!("Crypto error occurred"),
            _                      => tracing::warn!(error = %self, "Request error"),
        }

        let mut body = json!({
            "error": {
                "type": error_type,
                "message": detail,
                "status": status.as_u16(),
            }
        });

        // Include retry_after for rate-limited responses
        if let AppError::RateLimited { retry_after } = &self {
            body["error"]["retry_after"] = json!(retry_after);
        }

        let mut response = (status, Json(body)).into_response();

        // Add Retry-After header for rate limits
        if let AppError::RateLimited { retry_after } = &self {
            response.headers_mut().insert(
                "Retry-After",
                retry_after.to_string().parse().unwrap(),
            );
        }

        response
    }
}

impl From<mongodb::error::Error> for AppError {
    fn from(e: mongodb::error::Error) -> Self {
        AppError::Database(e.to_string())
    }
}

impl From<validator::ValidationErrors> for AppError {
    fn from(e: validator::ValidationErrors) -> Self {
        AppError::Validation(e.to_string())
    }
}

// Convenient Result alias used throughout the codebase
pub type AppResult<T> = Result<T, AppError>;
