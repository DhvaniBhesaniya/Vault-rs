# VaultRS 🔐

A production-grade, zero-knowledge password manager backend written in Rust.

**Stack:** Axum · MongoDB · Argon2id · AES-256-GCM · RS256 JWT · In-process rate limiting

---

## Quick Start

### Prerequisites

- Rust 1.75+ (`rustup update stable`)
- Docker & Docker Compose (for MongoDB)
- OpenSSL (for key generation)

### 1. Clone and bootstrap

```bash
git clone https://github.com/you/vaultrs
cd vaultrs
chmod +x scripts/bootstrap.sh
./scripts/bootstrap.sh
```

### 2. Start MongoDB

```bash
docker-compose up -d mongo
```

Update `.env` with the dev connection string:

```env
MONGODB_URI=mongodb://vaultrs:vaultrs_dev_password@localhost:27017/vaultrs?authSource=admin
MONGODB_DB=vaultrs
```

### 3. Run the server

```bash
cargo run
```

### 4. Verify

```bash
curl http://localhost:8080/health
# {"status":"ok","service":"vaultrs"}

curl http://localhost:8080/health/ready
# {"status":"ready","mongodb":"up"}
```

---

## Architecture

```
Client (React / curl)
    │
    ▼
Axum HTTP server (Tower middleware stack)
    ├── Request ID injection
    ├── TraceLayer (structured logs)
    ├── CORS
    ├── Compression
    │
    ├── [Public routes]  /health, /v1/auth/register, /v1/auth/login
    │
    └── [Protected routes]
            ├── JWT auth middleware (RS256 + security_stamp check)
            ├── Idempotency middleware (MongoDB-backed, 24h TTL)
            └── Handlers → Services → Repositories → MongoDB
```

### Zero-knowledge encryption

The server never has access to plaintext vault data. All encryption happens client-side:

```
Master Password (never sent)
    │
    ▼ Argon2id (client-side, m=64MB, t=4, p=4)
Master Key (256-bit)
    │
    ├─► HKDF-SHA256 → Encryption Key (EK)
    └─► HKDF-SHA256 → MAC Key
            │
            │  EK encrypts the Vault Key
            ▼
Protected Symmetric Key (stored on server, encrypted)
            │
            │  Client unwraps with EK → Vault Key
            ▼
AES-256-GCM (Vault Key) → each vault item

Server receives only:
  - Master Password Hash = PBKDF2(MasterKey, password)   ← for authentication
  - Encrypted vault item blobs                           ← opaque
```

---

## API Reference

All protected endpoints require `Authorization: Bearer <access_token>`.

### Authentication

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/auth/register` | Create account |
| `POST` | `/v1/auth/login` | Login (step 1: password) |
| `POST` | `/v1/auth/two-factor` | Login (step 2: TOTP) |
| `POST` | `/v1/auth/refresh` | Rotate refresh token |
| `POST` | `/v1/auth/logout` | Revoke current session |
| `POST` | `/v1/auth/logout-all` | Revoke all sessions |
| `GET`  | `/v1/auth/me` | Current user profile |
| `PUT`  | `/v1/auth/password` | Change master password |

#### Register

```bash
curl -X POST http://localhost:8080/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "master_password_hash": "<client-derived MPH, base64>",
    "protected_symmetric_key": "<AES-GCM encrypted vault key, base64>",
    "kdf_iterations": 4,
    "kdf_memory": 65536,
    "kdf_parallelism": 4,
    "kdf_salt": "<128-bit random salt, base64>"
  }'
```

#### Login

```bash
curl -X POST http://localhost:8080/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "master_password_hash": "<MPH>"
  }'
```

Response:
```json
{
  "requires_two_factor": false,
  "access_token": "eyJ...",
  "refresh_token": "...",
  "access_token_expires": 1706000900,
  "user": {
    "user_id": "...",
    "email": "user@example.com",
    "email_verified": true,
    "two_factor_enabled": false,
    "protected_symmetric_key": "...",
    "kdf": { "algorithm": "argon2id", "iterations": 4, "memory": 65536, "parallelism": 4, "salt": "..." }
  }
}
```

#### Refresh

Send `Idempotency-Key` header to prevent double-issuance on network retry:

```bash
curl -X POST http://localhost:8080/v1/auth/refresh \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: $(uuidgen)" \
  -d '{ "refresh_token": "..." }'
```

---

### Vault Items

| Method | Path | Description |
|--------|------|-------------|
| `GET`    | `/v1/vault/items`                | List items (paginated) |
| `POST`   | `/v1/vault/items`                | Create item |
| `GET`    | `/v1/vault/items/:id`            | Get single item |
| `PUT`    | `/v1/vault/items/:id`            | Replace item |
| `PATCH`  | `/v1/vault/items/:id`            | Partial update (favourite, reprompt) |
| `DELETE` | `/v1/vault/items/:id`            | Soft delete (trash) |
| `POST`   | `/v1/vault/items/:id/restore`    | Restore from trash |
| `DELETE` | `/v1/vault/items/:id/permanent`  | Permanent delete |

#### Create item

```bash
curl -X POST http://localhost:8080/v1/vault/items \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: $(uuidgen)" \
  -d '{
    "item_type": "login",
    "name": "<encrypted name>",
    "encrypted_data": "$aes256gcm$<base64 blob>",
    "favourite": false,
    "reprompt": false
  }'
```

#### List items (cursor pagination)

```bash
curl "http://localhost:8080/v1/vault/items?limit=50" \
  -H "Authorization: Bearer $TOKEN"

# Next page:
curl "http://localhost:8080/v1/vault/items?limit=50&after=<next_cursor>" \
  -H "Authorization: Bearer $TOKEN"
```

---

### Collections

| Method | Path | Description |
|--------|------|-------------|
| `GET`    | `/v1/vault/collections`     | List collections |
| `POST`   | `/v1/vault/collections`     | Create collection |
| `DELETE` | `/v1/vault/collections/:id` | Delete collection |

---

## Idempotency

Send `Idempotency-Key: <uuid>` on any `POST`, `PUT`, `PATCH`, or `DELETE` request.
If the same key is sent again within 24 hours, the stored response is replayed verbatim with header `X-Idempotency-Replayed: true`. Safe to retry on network failure.

---

## Rate Limits

| Endpoint | Window | Limit |
|----------|--------|-------|
| `POST /auth/login` | 5 min | 5 per IP+email |
| `POST /auth/register` | 1 hour | 10 per IP |
| `POST /auth/two-factor` | 10 min | 10 per IP |
| `GET /vault/items` | 1 min | 120 per user |
| `POST /vault/items` | 1 min | 30 per user |
| `DELETE /vault/items/*` | 1 min | 10 per user |

Rate-limited responses return HTTP 429 with headers:
```
Retry-After: 60
X-RateLimit-Limit: 30
X-RateLimit-Remaining: 0
```

---

## Error Format

All errors follow a consistent envelope:

```json
{
  "error": {
    "type": "invalid_credentials",
    "message": "Invalid credentials",
    "status": 401
  }
}
```

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `8080` | Listen port |
| `MONGODB_URI` | required | MongoDB connection string |
| `MONGODB_DB` | required | Database name |
| `JWT_PRIVATE_KEY_PATH` | required | Path to RSA-4096 PEM |
| `JWT_PUBLIC_KEY_PATH` | required | Path to RSA public key PEM |
| `JWT_ACCESS_EXPIRY_SECONDS` | `900` | 15 minutes |
| `JWT_REFRESH_EXPIRY_DAYS` | `30` | 30 days |
| `ARGON2_MEMORY_KIB` | `65536` | 64 MB |
| `ARGON2_ITERATIONS` | `3` | Argon2id time cost |
| `ARGON2_PARALLELISM` | `4` | Argon2id lanes |
| `ALLOWED_ORIGINS` | `http://localhost:3000` | CORS origins (comma-separated) |
| `MAX_LOGIN_ATTEMPTS` | `5` | Before account lockout |
| `LOCKOUT_DURATION_MINUTES` | `15` | Lockout duration |
| `REQUIRE_EMAIL_VERIFICATION` | `false` | Enforce email verification |

---

## Project Structure

```
src/
├── main.rs              # Entry point, server setup
├── config.rs            # Environment config loading
├── error.rs             # AppError → HTTP response mapping
├── state.rs             # Shared AppState
├── db.rs                # MongoDB connection + index bootstrap
├── rate_limit.rs        # In-process governor-based rate limiter
│
├── crypto/
│   ├── argon2.rs        # Argon2id hash + verify
│   ├── aes_gcm.rs       # AES-256-GCM encrypt + decrypt
│   ├── jwt.rs           # RS256 JWT sign + verify
│   └── keys.rs          # Opaque token generation + SHA-256 hashing
│
├── middleware/
│   ├── auth.rs          # JWT extraction, security_stamp check
│   ├── idempotency.rs   # Request deduplication
│   └── request_id.rs    # X-Request-Id injection
│
├── models/              # MongoDB document structs
├── dto/                 # Request/response types (validated)
├── repositories/        # DB query layer
├── services/            # Business logic
└── routes/              # Axum handlers
```

---

## Security

- **Zero-knowledge**: server stores only ciphertext, never plaintext
- **Argon2id** (m=64MB, t=3–4, p=4) for all password hashing — two layers: client + server
- **AES-256-GCM** with per-item 96-bit random IV and AAD binding prevents ciphertext transplant attacks
- **RS256 JWT** (15-min access) + opaque refresh tokens with rotation and family theft detection
- **`secrecy::Secret<T>`** + **`zeroize`** — sensitive keys are zeroed from memory on drop
- **`constant_time_eq`** — all hash comparisons are timing-safe
- Account lockout after configurable failed login attempts
- All MongoDB queries include `user_id` predicate (defence-in-depth against RBAC bypass)
- Audit log of every auth and vault event (TTL: 90 days)
- Idempotency prevents duplicate vault items on network retry

---

## Roadmap

- [ ] TOTP 2FA full implementation
- [ ] WebAuthn / FIDO2 support
- [ ] Organization / team sharing (RSA-OAEP vault key sharing)
- [ ] Import / export (Bitwarden-compatible JSON)
- [ ] HIBP breach check on login
- [ ] Emergency access
- [ ] Admin endpoints
- [ ] OpenTelemetry tracing
- [ ] React frontend
