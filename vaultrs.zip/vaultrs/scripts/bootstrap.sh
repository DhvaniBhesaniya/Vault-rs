#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# VaultRS bootstrap script
# Generates RSA-4096 key pair and copies .env.example → .env
# Run once before `cargo run`
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

echo "==> VaultRS bootstrap"

# ── 1. Create keys directory ─────────────────────────────────────────────────
mkdir -p keys

# ── 2. Generate RSA-4096 key pair ────────────────────────────────────────────
if [ ! -f keys/private.pem ]; then
    echo "--> Generating RSA-4096 private key..."
    openssl genrsa -out keys/private.pem 4096 2>/dev/null
    echo "--> Extracting public key..."
    openssl rsa -in keys/private.pem -pubout -out keys/public.pem 2>/dev/null
    echo "    Keys written to keys/private.pem and keys/public.pem"
else
    echo "--> RSA keys already exist, skipping"
fi

# ── 3. Copy .env.example → .env ──────────────────────────────────────────────
if [ ! -f .env ]; then
    cp .env.example .env
    echo "--> Created .env from .env.example"
    echo "    Edit .env to set MONGODB_URI and other values before starting"
else
    echo "--> .env already exists, skipping"
fi

echo ""
echo "==> Bootstrap complete!"
echo ""
echo "    Next steps:"
echo "    1. Edit .env — set MONGODB_URI to your MongoDB connection string"
echo "    2. Start MongoDB:  docker run -d -p 27017:27017 mongo:7"
echo "    3. Run the server: cargo run"
echo "    4. Test health:    curl http://localhost:8080/health"
